using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks; // For async operations
using System.Text; // For encoding/decoding

public class SaveLoadManager : MonoBehaviour
{
    // Events for other systems to subscribe to for saving/loading data
    public event Action<object> OnSaveGameDataRequest; // Request data from systems
    public event Action<object> OnLoadGameData; // Provide loaded data to systems
    public event Action<bool, string> OnGameSaved; // Notify UI of save outcome
    public event Action<bool, string> OnGameLoaded; // Notify UI of load outcome
    public event Action<List<SaveSlotData>> OnSaveSlotsQueried; // Notify UI with save slot info

    [Header("Dependencies")]
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private InventoryManager inventoryManager;
    [SerializeField] private QuestManager questManager;
    [SerializeField] private WorldManager worldManager;
    [SerializeField] private UIManager uiManager; // For displaying messages

    [Header("Save Settings")]
    [SerializeField] private string saveFileNamePrefix = "JamJam_Save_Slot_";
    [SerializeField] private string saveFileExtension = ".json";
    [SerializeField] private string encryptionKey = "JamJamWorlSecretKey!123"; // Simple XOR key, NOT for real security

    public const int MaxSaveSlots = 3; // As per GDD

    private void Awake()
    {
        // Ensure all required managers are assigned
        if (playerStats == null) Debug.LogError("SaveLoadManager: PlayerStats is not assigned.");
        if (inventoryManager == null) Debug.LogError("SaveLoadManager: InventoryManager is not assigned.");
        if (questManager == null) Debug.LogError("SaveLoadManager: QuestManager is not assigned.");
        if (worldManager == null) Debug.LogError("SaveLoadManager: WorldManager is not assigned.");
        if (uiManager == null) Debug.LogError("SaveLoadManager: UIManager is not assigned.");
    }

    /// <summary>
    /// Saves the current game state to a specified slot.
    /// This operation runs asynchronously to prevent game hiccups.
    /// </summary>
    /// <param name="slotIndex">The index of the save slot (0 to MaxSaveSlots-1).</param>
    public async void SaveGame(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= MaxSaveSlots)
        {
            OnGameSaved?.Invoke(false, $"Save failed: Invalid slot index {slotIndex}.");
            return;
        }

        Debug.Log($"Attempting to save game to slot {slotIndex}...");

        try
        {
            GameSaveData saveData = new GameSaveData
            {
                Timestamp = DateTime.Now,
                // Get data from various managers using their GetSaveData methods
                playerData = GetPlayerSaveData(),
                inventoryData = inventoryManager.GetInventorySaveData(),
                questData = questManager.GetQuestSaveData(),
                worldData = GetWorldSaveData()
            };

            string json = JsonUtility.ToJson(saveData, true); // Pretty print for debugging
            string encryptedJson = EncryptDecrypt(json, encryptionKey);

            string filePath = GetSaveFilePath(slotIndex);

            await Task.Run(() => File.WriteAllText(filePath, encryptedJson));

            Debug.Log($"Game saved successfully to slot {slotIndex} at {saveData.Timestamp}.");
            OnGameSaved?.Invoke(true, $"Game Saved! Slot {slotIndex + 1}");

            // Immediately update UI to reflect new save data
            QuerySaveSlots();
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to save game to slot {slotIndex}: {e.Message}");
            OnGameSaved?.Invoke(false, $"Save failed! Slot {slotIndex + 1}");
        }
    }

    /// <summary>
    /// Loads the game state from a specified slot.
    /// This operation runs asynchronously to prevent game hiccups.
    /// </summary>
    /// <param name="slotIndex">The index of the save slot (0 to MaxSaveSlots-1).</param>
    public async void LoadGame(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= MaxSaveSlots)
        {
            OnGameLoaded?.Invoke(false, $"Load failed: Invalid slot index {slotIndex}.");
            return;
        }

        string filePath = GetSaveFilePath(slotIndex);

        if (!File.Exists(filePath))
        {
            Debug.LogWarning($"No save data found in slot {slotIndex}.");
            OnGameLoaded?.Invoke(false, $"Load failed: No data in slot {slotIndex + 1}");
            return;
        }

        Debug.Log($"Attempting to load game from slot {slotIndex}...");

        try
        {
            string encryptedJson = await Task.Run(() => File.ReadAllText(filePath));
            string json = EncryptDecrypt(encryptedJson, encryptionKey);

            GameSaveData loadedData = JsonUtility.FromJson<GameSaveData>(json);

            // Apply loaded data to various managers
            ApplyPlayerSaveData(loadedData.playerData);
            inventoryManager.LoadInventoryState(loadedData.inventoryData);
            questManager.LoadQuestState(loadedData.questData);
            ApplyWorldSaveData(loadedData.worldData);

            Debug.Log($"Game loaded successfully from slot {slotIndex} ({loadedData.Timestamp}).");
            OnGameLoaded?.Invoke(true, $"Game Loaded! Slot {slotIndex + 1}");
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to load game from slot {slotIndex}: {e.Message}");
            OnGameLoaded?.Invoke(false, $"Load failed! Slot {slotIndex + 1}");
        }
    }

    /// <summary>
    /// Checks if a save slot contains data.
    /// </summary>
    /// <param name="slotIndex">The index of the save slot.</param>
    /// <returns>True if data exists, false otherwise.</returns>
    public bool HasSaveData(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= MaxSaveSlots)
        {
            return false;
        }
        return File.Exists(GetSaveFilePath(slotIndex));
    }

    /// <summary>
    /// Retrieves a list of all save slot data for UI display.
    /// This includes metadata like timestamp and a summary.
    /// </summary>
    /// <returns>A list of SaveSlotData objects.</returns>
    public List<SaveSlotData> GetAllSaveSlots()
    {
        List<SaveSlotData> slots = new List<SaveSlotData>();
        for (int i = 0; i < MaxSaveSlots; i++)
        {
            string filePath = GetSaveFilePath(i);
            if (File.Exists(filePath))
            {
                try
                {
                    // For performance, only load minimal data needed for display (timestamp).
                    // This assumes GameSaveData has a Timestamp field at the top level.
                    // If not, we would need a separate metadata file or a more robust parsing.
                    string encryptedJson = File.ReadAllText(filePath);
                    string json = EncryptDecrypt(encryptedJson, encryptionKey);
                    
                    // Parse only the timestamp, or create a lightweight metadata struct for this purpose
                    // For simplicity, we'll deserialize the whole thing for now, but optimize if needed.
                    GameSaveData tempSaveData = JsonUtility.FromJson<GameSaveData>(json);
                    
                    slots.Add(new SaveSlotData
                    {
                        SlotIndex = i,
                        Timestamp = tempSaveData.Timestamp,
                        PlayerLocation = "Unknown Location" // Placeholder, would need to be stored in worldData
                    });
                }
                catch (Exception e)
                {
                    Debug.LogError($"Error reading save file metadata for slot {i}: {e.Message}");
                    slots.Add(new SaveSlotData { SlotIndex = i, Timestamp = DateTime.MinValue, PlayerLocation = "Corrupted Data" });
                }
            }
            else
            {
                slots.Add(new SaveSlotData { SlotIndex = i, Timestamp = DateTime.MinValue, PlayerLocation = "Empty" });
            }
        }
        return slots;
    }

    /// <summary>
    /// Queries the current state of all save slots and invokes the OnSaveSlotsQueried event.
    /// </summary>
    public void QuerySaveSlots()
    {
        OnSaveSlotsQueried?.Invoke(GetAllSaveSlots());
    }

    /// <summary>
    /// Gets the full path for a save file.
    /// </summary>
    /// <param name="slotIndex">The index of the save slot.</param>
    /// <returns>The full file path.</returns>
    private string GetSaveFilePath(int slotIndex)
    {
        return Path.Combine(Application.persistentDataPath, $"{saveFileNamePrefix}{slotIndex}{saveFileExtension}");
    }

    /// <summary>
    /// Simple XOR encryption/decryption. This is NOT secure for production,
    /// but fulfills the "encryption utility" requirement.
    /// For real security, use AES with proper key management.
    /// </summary>
    /// <param name="data">The string to encrypt or decrypt.</param>
    /// <param name="key">The encryption key.</param>
    /// <returns>The encrypted or decrypted string.</returns>
    private string EncryptDecrypt(string data, string key)
    {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < data.Length; i++)
        {
            result.Append((char)(data[i] ^ key[i % key.Length]));
        }
        return result.ToString();
    }

    /// <summary>
    /// Serializes PlayerStats data into a PlayerSaveData object.
    /// </summary>
    /// <returns>A PlayerSaveData object.</returns>
    private PlayerSaveData GetPlayerSaveData()
    {
        return new PlayerSaveData
        {
            health = playerStats.Health,
            stamina = playerStats.Stamina,
            hunger = playerStats.Hunger,
            thirst = playerStats.Thirst,
            sanity = playerStats.Sanity
        };
    }

    /// <summary>
    /// Applies loaded PlayerSaveData to the PlayerStats manager.
    /// </summary>
    /// <param name="data">The PlayerSaveData object.</param>
    private void ApplyPlayerSaveData(PlayerSaveData data)
    {
        playerStats.SetAllStats(data.health, data.stamina, data.hunger, data.thirst, data.sanity);
    }

    /// <summary>
    /// Serializes relevant WorldManager data. Placeholder for full implementation.
    /// </summary>
    /// <returns>A WorldSaveData object.</returns>
    private WorldSaveData GetWorldSaveData()
    {
        // For now, only saving current weather. Extend as needed.
        return new WorldSaveData
        {
            currentWeather = worldManager.GetCurrentWeather().ToString() // Convert enum to string
            // Add other world state data like time of day, activated events, etc.
        };
    }

    /// <summary>
    /// Applies loaded WorldSaveData to the WorldManager.
    /// </summary>
    /// <param name="data">The WorldSaveData object.</param>
    private void ApplyWorldSaveData(WorldSaveData data)
    {
        if (Enum.TryParse(data.currentWeather, out WorldManager.WeatherType weatherType))
        {
            worldManager.SetWeather(weatherType, true); // Set instantly upon load
        }
        else
        {
            Debug.LogWarning($"Failed to parse weather type: {data.currentWeather}");
        }
        // Apply other world state data
    }


    /// <summary>
    /// Represents the complete game state to be saved.
    /// </summary>
    [Serializable]
    private class GameSaveData
    {
        public DateTime Timestamp;
        public PlayerSaveData playerData;
        public InventoryManager.InventorySaveData inventoryData; // Directly use InventoryManager's serializable class
        public QuestManager.QuestSaveData questData; // Directly use QuestManager's serializable class
        public WorldSaveData worldData;
        // Add other manager save data here (e.g., Crafting, Creature, etc.)
    }

    /// <summary>
    /// Serializable class for PlayerStats data.
    /// </summary>
    [Serializable]
    private class PlayerSaveData
    {
        public float health;
        public float stamina;
        public float hunger;
        public float thirst;
        public float sanity;
    }

    /// <summary>
    /// Serializable class for WorldManager data.
    /// </summary>
    [Serializable]
    private class WorldSaveData
    {
        public string currentWeather; // Storing as string for simpler serialization of enum
        // Add other persistent world state here (e.g., time of day, active events, specific object states)
    }

    /// <summary>
    /// Enum for save/load panel mode, used by UIManager.
    /// </summary>
    public enum SaveLoadMode
    {
        Save,
        Load
    }
}

/// <summary>
/// Serializable class representing summary data for a single save slot.
/// Used by UIManager to display save slot information.
/// </summary>
[Serializable]
public class SaveSlotData
{
    public int SlotIndex;
    public DateTime Timestamp;
    public string PlayerLocation; // Example: "Near Ancient Ruins"
}