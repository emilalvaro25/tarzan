// Required Packages:
// - com.unity.modules.ai

using UnityEngine;
using UnityEngine.AI;
using System;
using System.Collections.Generic;
using Random = UnityEngine.Random;

public class WorldManager : MonoBehaviour
{
    public enum WeatherType
    {
        Clear,
        Rain,
        Thunderstorm,
        Fog,
        LunarEclipse // Special event, not a typical weather
    }

    [Header("Dependencies")]
    [SerializeField] private QuestManager questManager; // To receive TriggerLunarEclipse calls from QuestManager
    [SerializeField] private AudioManager audioManager; // To notify for ambient sounds
    [SerializeField] private PostProcessEffectController postProcessEffectController; // To notify for visual changes

    [Header("Weather Settings")]
    [SerializeField] private WeatherType currentWeather = WeatherType.Clear;
    [SerializeField] private float weatherTransitionDuration = 10f; // Duration for weather to smoothly transition
    [SerializeField] private ParticleSystem rainParticleSystem; // Assign a Particle System prefab for rain
    [SerializeField] private Light sunLight; // Main directional light for sun/moon
    [SerializeField] private Material skyboxMaterial; // Assign a skybox material for dynamic changes

    [Header("Ocean Settings")]
    [SerializeField] private GameObject oceanPrefab; // Assign an ocean prefab with a shader
    private GameObject currentOceanInstance;

    [Header("World Generation/Management (Placeholder)")]
    // In a real game, this would manage chunk loading/unloading
    [SerializeField] private Terrain terrain; // Reference to the Unity Terrain
    private NavMeshSurface navMeshSurface; // If using NavMesh for pathfinding

    private WeatherType _targetWeather;
    private float _weatherTransitionTimer;
    private float _initialRainEmissionRate;
    private Color _initialSkyboxTint;

    private const string SKYBOX_TINT_PROPERTY = "_Tint";
    private const string SKYBOX_EXPOSURE_PROPERTY = "_Exposure";

    private void Awake()
    {
        if (questManager == null) Debug.LogError("WorldManager: QuestManager is not assigned.", this);
        if (audioManager == null) Debug.LogError("WorldManager: AudioManager is not assigned.", this);
        if (postProcessEffectController == null) Debug.LogError("WorldManager: PostProcessEffectController is not assigned.", this);
        if (rainParticleSystem == null) Debug.LogWarning("WorldManager: Rain Particle System is not assigned. Rain effects will not play.", this);
        if (sunLight == null) Debug.LogWarning("WorldManager: Sun Light is not assigned. Dynamic lighting changes may not work.", this);
        if (skyboxMaterial == null) Debug.LogWarning("WorldManager: Skybox Material is not assigned. Skybox changes may not work.", this);
        if (terrain == null) Debug.LogWarning("WorldManager: Terrain is not assigned. GetRandomNavigablePoint might not work as expected.", this);

        // Try to get NavMeshSurface if not assigned
        navMeshSurface = FindObjectOfType<NavMeshSurface>();
        if (navMeshSurface == null)
        {
            Debug.LogWarning("WorldManager: No NavMeshSurface found in scene. `GetRandomNavigablePoint` might not work correctly.");
        }

        // Store initial rain emission rate
        if (rainParticleSystem != null)
        {
            _initialRainEmissionRate = rainParticleSystem.emission.rateOverTime.constant;
        }

        // Store initial skybox tint if a material is assigned
        if (skyboxMaterial != null && skyboxMaterial.HasProperty(SKYBOX_TINT_PROPERTY))
        {
            _initialSkyboxTint = skyboxMaterial.GetColor(SKYBOX_TINT_PROPERTY);
        }

        // Initialize ocean
        if (oceanPrefab != null)
        {
            currentOceanInstance = Instantiate(oceanPrefab, Vector3.zero, Quaternion.identity, transform);
            currentOceanInstance.name = "GameOcean";
        }
    }

    private void Start()
    {
        // Set initial weather state
        SetWeather(currentWeather, true); // Force instant transition at start
    }

    private void Update()
    {
        // Handle weather transitions
        if (_weatherTransitionTimer > 0)
        {
            _weatherTransitionTimer -= Time.deltaTime;
            float progress = 1 - (_weatherTransitionTimer / weatherTransitionDuration);

            ApplyWeatherEffectInterpolation(currentWeather, _targetWeather, progress);

            if (_weatherTransitionTimer <= 0)
            {
                currentWeather = _targetWeather;
                // Ensure final state is set precisely
                ApplyWeatherEffectInterpolation(currentWeather, currentWeather, 1f); 
                Debug.Log($"Weather fully transitioned to: {currentWeather}");
            }
        }

        // Example: Randomly change weather for testing (remove for production)
        // if (Input.GetKeyDown(KeyCode.P))
        // {
        //     WeatherType[] types = (WeatherType[])Enum.GetValues(typeof(WeatherType));
        //     WeatherType newType = types[Random.Range(0, types.Length)];
        //     SetWeather(newType);
        // }
    }

    /// <summary>
    /// Sets the current weather type and initiates a transition.
    /// </summary>
    /// <param name="newWeather">The target weather type.</param>
    /// <param name="instant">If true, the transition is instant, otherwise it's gradual.</param>
    public void SetWeather(WeatherType newWeather, bool instant = false)
    {
        if (currentWeather == newWeather && !instant)
        {
            Debug.Log($"WorldManager: Already in {newWeather} weather.");
            return;
        }

        Debug.Log($"WorldManager: Changing weather from {currentWeather} to {newWeather}");
        _targetWeather = newWeather;

        if (instant)
        {
            currentWeather = _targetWeather;
            _weatherTransitionTimer = 0f;
            ApplyWeatherEffects(currentWeather);
            Debug.Log($"Weather instantly set to: {currentWeather}");
        }
        else
        {
            _weatherTransitionTimer = weatherTransitionDuration;
        }
        
        // Notify other systems immediately about the change initiation
        audioManager?.SetAmbientSound(newWeather);
        postProcessEffectController?.ApplyWeatherPostProcess(newWeather);
    }

    /// <summary>
    /// Gets the currently active weather type.
    /// </summary>
    /// <returns>The current WeatherType.</returns>
    public WeatherType GetCurrentWeather()
    {
        return currentWeather;
    }

    /// <summary>
    /// Triggers a special Lunar Eclipse event.
    /// </summary>
    public void TriggerLunarEclipse()
    {
        Debug.Log("WorldManager: Lunar Eclipse event triggered!");
        SetWeather(WeatherType.LunarEclipse, false); // Lunar eclipse should likely be a gradual transition
        // Additional specific effects for lunar eclipse could go here
        // e.g., trigger special creature spawns, unique visual distortions
    }

    /// <summary>
    /// Finds a random navigable point within a specified range from an origin.
    /// Uses Unity's NavMesh system.
    /// </summary>
    /// <param name="origin">The center point for the search.</param>
    /// <param name="range">The maximum distance from the origin to search.</param>
    /// <returns>A random navigable point, or Vector3.zero if none found.</returns>
    public Vector3 GetRandomNavigablePoint(Vector3 origin, float range)
    {
        if (navMeshSurface == null)
        {
            Debug.LogWarning("WorldManager: NavMeshSurface not found, cannot find random navigable point.");
            return Vector3.zero;
        }

        for (int i = 0; i < 10; i++) // Try a few times to find a point
        {
            Vector3 randomDirection = Random.insideUnitSphere * range;
            randomDirection += origin;
            NavMeshHit hit;
            if (NavMesh.SamplePosition(randomDirection, out hit, range, NavMesh.AllAreas))
            {
                return hit.position;
            }
        }
        Debug.LogWarning($"WorldManager: Could not find a navigable point within range {range} of {origin}.");
        return Vector3.zero;
    }

    /// <summary>
    /// Applies weather-specific effects directly (used for instant transitions or final state).
    /// </summary>
    /// <param name="weather">The weather type to apply effects for.</param>
    private void ApplyWeatherEffects(WeatherType weather)
    {
        ParticleSystem.EmissionModule rainEmission = rainParticleSystem != null ? rainParticleSystem.emission : default;
        
        // Reset properties
        if (rainParticleSystem != null)
        {
            rainEmission.rateOverTime = 0;
            if (rainParticleSystem.isPlaying) rainParticleSystem.Stop();
        }
        if (sunLight != null)
        {
            sunLight.intensity = 1f; // Default sun intensity
            sunLight.color = Color.white; // Default sun color
        }
        if (skyboxMaterial != null && skyboxMaterial.HasProperty(SKYBOX_TINT_PROPERTY))
        {
            skyboxMaterial.SetColor(SKYBOX_TINT_PROPERTY, _initialSkyboxTint);
            skyboxMaterial.SetFloat(SKYBOX_EXPOSURE_PROPERTY, 1.0f); // Default exposure
        }

        switch (weather)
        {
            case WeatherType.Clear:
                // No specific effects needed, already reset
                break;
            case WeatherType.Rain:
                if (rainParticleSystem != null)
                {
                    rainEmission.rateOverTime = _initialRainEmissionRate;
                    if (!rainParticleSystem.isPlaying) rainParticleSystem.Play();
                }
                if (sunLight != null) sunLight.intensity = 0.7f; // Dim light
                if (skyboxMaterial != null && skyboxMaterial.HasProperty(SKYBOX_TINT_PROPERTY))
                {
                    skyboxMaterial.SetColor(SKYBOX_TINT_PROPERTY, new Color(0.7f, 0.75f, 0.8f)); // Greyish sky
                }
                break;
            case WeatherType.Thunderstorm:
                if (rainParticleSystem != null)
                {
                    rainEmission.rateOverTime = _initialRainEmissionRate * 1.5f; // Heavier rain
                    if (!rainParticleSystem.isPlaying) rainParticleSystem.Play();
                }
                if (sunLight != null) sunLight.intensity = 0.4f; // Very dim
                if (skyboxMaterial != null && skyboxMaterial.HasProperty(SKYBOX_TINT_PROPERTY))
                {
                    skyboxMaterial.SetColor(SKYBOX_TINT_PROPERTY, new Color(0.4f, 0.45f, 0.5f)); // Darker grey
                }
                // (Optional: Implement random lightning flashes here)
                break;
            case WeatherType.Fog:
                if (sunLight != null) sunLight.intensity = 0.6f; // Dim light
                if (skyboxMaterial != null && skyboxMaterial.HasProperty(SKYBOX_TINT_PROPERTY))
                {
                    skyboxMaterial.SetColor(SKYBOX_TINT_PROPERTY, new Color(0.85f, 0.85f, 0.8f)); // Muted sky
                    skyboxMaterial.SetFloat(SKYBOX_EXPOSURE_PROPERTY, 0.7f); // Reduced exposure
                }
                break;
            case WeatherType.LunarEclipse:
                if (sunLight != null)
                {
                    sunLight.intensity = 0.1f; // Very dark
                    sunLight.color = new Color(0.2f, 0.1f, 0.3f); // Reddish/purplish tint
                }
                if (skyboxMaterial != null && skyboxMaterial.HasProperty(SKYBOX_TINT_PROPERTY))
                {
                    skyboxMaterial.SetColor(SKYBOX_TINT_PROPERTY, new Color(0.1f, 0.05f, 0.15f)); // Deep dark sky
                    skyboxMaterial.SetFloat(SKYBOX_EXPOSURE_PROPERTY, 0.1f); // Extremely low exposure
                }
                break;
        }
    }

    /// <summary>
    /// Interpolates weather effects between the start and target weather types.
    /// </summary>
    /// <param name="startWeather">The weather type at the beginning of the transition.</param>
    /// <param name="targetWeather">The weather type at the end of the transition.</param>
    /// <param name="t">The interpolation factor (0.0 to 1.0).</param>
    private void ApplyWeatherEffectInterpolation(WeatherType startWeather, WeatherType targetWeather, float t)
    {
        // Define target values for each weather type
        Dictionary<WeatherType, float> targetRainRates = new Dictionary<WeatherType, float>
        {
            {WeatherType.Clear, 0f},
            {WeatherType.Rain, _initialRainEmissionRate},
            {WeatherType.Thunderstorm, _initialRainEmissionRate * 1.5f},
            {WeatherType.Fog, 0f},
            {WeatherType.LunarEclipse, 0f}
        };

        Dictionary<WeatherType, float> targetSunIntensities = new Dictionary<WeatherType, float>
        {
            {WeatherType.Clear, 1f},
            {WeatherType.Rain, 0.7f},
            {WeatherType.Thunderstorm, 0.4f},
            {WeatherType.Fog, 0.6f},
            {WeatherType.LunarEclipse, 0.1f}
        };

        Dictionary<WeatherType, Color> targetSunColors = new Dictionary<WeatherType, Color>
        {
            {WeatherType.Clear, Color.white},
            {WeatherType.Rain, Color.white},
            {WeatherType.Thunderstorm, Color.white},
            {WeatherType.Fog, Color.white},
            {WeatherType.LunarEclipse, new Color(0.2f, 0.1f, 0.3f)}
        };

        Dictionary<WeatherType, Color> targetSkyboxTints = new Dictionary<WeatherType, Color>
        {
            {WeatherType.Clear, _initialSkyboxTint},
            {WeatherType.Rain, new Color(0.7f, 0.75f, 0.8f)},
            {WeatherType.Thunderstorm, new Color(0.4f, 0.45f, 0.5f)},
            {WeatherType.Fog, new Color(0.85f, 0.85f, 0.8f)},
            {WeatherType.LunarEclipse, new Color(0.1f, 0.05f, 0.15f)}
        };

        Dictionary<WeatherType, float> targetSkyboxExposures = new Dictionary<WeatherType, float>
        {
            {WeatherType.Clear, 1.0f},
            {WeatherType.Rain, 1.0f},
            {WeatherType.Thunderstorm, 1.0f},
            {WeatherType.Fog, 0.7f},
            {WeatherType.LunarEclipse, 0.1f}
        };


        // Get current and target values
        float currentRainRate = targetRainRates[startWeather];
        float targetRainRate = targetRainRates[targetWeather];

        float currentSunIntensity = targetSunIntensities[startWeather];
        float targetSunIntensity = targetSunIntensities[targetWeather];

        Color currentSunColor = targetSunColors[startWeather];
        Color targetSunColor = targetSunColors[targetWeather];

        Color currentSkyboxTint = targetSkyboxTints[startWeather];
        Color targetSkyboxTint = targetSkyboxTints[targetWeather];

        float currentSkyboxExposure = targetSkyboxExposures[startWeather];
        float targetSkyboxExposure = targetSkyboxExposures[targetWeather];

        // Interpolate values
        float interpolatedRainRate = Mathf.Lerp(currentRainRate, targetRainRate, t);
        float interpolatedSunIntensity = Mathf.Lerp(currentSunIntensity, targetSunIntensity, t);
        Color interpolatedSunColor = Color.Lerp(currentSunColor, targetSunColor, t);
        Color interpolatedSkyboxTint = Color.Lerp(currentSkyboxTint, targetSkyboxTint, t);
        float interpolatedSkyboxExposure = Mathf.Lerp(currentSkyboxExposure, targetSkyboxExposure, t);

        // Apply interpolated values
        if (rainParticleSystem != null)
        {
            ParticleSystem.EmissionModule emission = rainParticleSystem.emission;
            emission.rateOverTime = interpolatedRainRate;
            if (interpolatedRainRate > 0 && !rainParticleSystem.isPlaying)
            {
                rainParticleSystem.Play();
            }
            else if (interpolatedRainRate <= 0 && rainParticleSystem.isPlaying)
            {
                rainParticleSystem.Stop();
            }
        }

        if (sunLight != null)
        {
            sunLight.intensity = interpolatedSunIntensity;
            sunLight.color = interpolatedSunColor;
        }

        if (skyboxMaterial != null)
        {
            if (skyboxMaterial.HasProperty(SKYBOX_TINT_PROPERTY))
            {
                skyboxMaterial.SetColor(SKYBOX_TINT_PROPERTY, interpolatedSkyboxTint);
            }
            if (skyboxMaterial.HasProperty(SKYBOX_EXPOSURE_PROPERTY))
            {
                skyboxMaterial.SetFloat(SKYBOX_EXPOSURE_PROPERTY, interpolatedSkyboxExposure);
            }
        }
    }

    // Placeholder for chunk loading/unloading management
    // private void LoadChunk(Vector3 chunkPosition) { /* ... */ }
    // private void UnloadChunk(Vector3 chunkPosition) { /* ... */ }
}