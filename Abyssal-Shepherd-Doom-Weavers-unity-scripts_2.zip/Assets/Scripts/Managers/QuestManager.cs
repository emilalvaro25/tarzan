using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;
using System;
using System.Linq; // Required for LINQ operations like .FirstOrDefault()

// QuestData ScriptableObject Definition
[CreateAssetMenu(fileName = "NewQuest", menuName = "Quests/Quest Data")]
public class QuestData : ScriptableObject
{
    public string QuestID = Guid.NewGuid().ToString();
    public string QuestName = "New Quest";
    [TextArea(3, 5)]
    public string QuestDescription = "A new quest description.";
    public List<QuestObjective> Objectives = new List<QuestObjective>();
    public bool IsMainQuest = false; // True for main story quests, false for side quests
    public MemoryFragmentData MemoryFragmentToUnlock; // Optional: Memory Fragment awarded upon quest completion

    [HideInInspector] public bool IsStarted; // Runtime state
    [HideInInspector] public bool IsCompleted; // Runtime state

    /// <summary>
    /// Resets the quest's runtime state for a fresh start or testing.
    /// </summary>
    public void ResetQuestState()
    {
        IsStarted = false;
        IsCompleted = false;
        foreach (var obj in Objectives)
        {
            obj.IsCompleted = false;
        }
    }

    /// <summary>
    /// Checks if all objectives for this quest are completed.
    /// </summary>
    public bool AreAllObjectivesCompleted()
    {
        return Objectives.All(obj => obj.IsCompleted);
    }
}

// QuestObjective Definition
[System.Serializable]
public class QuestObjective
{
    public string ObjectiveID = Guid.NewGuid().ToString(); // Unique ID for this objective within its quest
    [TextArea(1, 3)]
    public string Description = "New Objective";
    public bool IsCompleted; // Runtime state

    public QuestObjective(string description)
    {
        Description = description;
        IsCompleted = false;
    }
}

// MemoryFragmentData ScriptableObject Definition
[CreateAssetMenu(fileName = "NewMemoryFragment", menuName = "Quests/Memory Fragment Data")]
public class MemoryFragmentData : ScriptableObject
{
    public string FragmentID = Guid.NewGuid().ToString();
    public string FragmentName = "New Memory Fragment";
    [TextArea(5, 10)]
    public string FragmentDescription = "A new memory fragment details the past.";
    public List<StatEffect> StatBoosts; // Stat boosts this fragment provides (e.g., permanent health increase)

    // Placeholder for visual/audio assets. In a real game, you'd load these at runtime.
    // public Sprite FragmentVisual;
    // public AudioClip FragmentAudio;
    // public VideoClip VideoClip;
}

public class QuestManager : MonoBehaviour
{
    // Dependencies
    [SerializeField] private UIManager uiManager;
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private SaveLoadManager saveLoadManager;

    [Header("Quest Data Assets")]
    [Tooltip("All possible quests in the game. These are ScriptableObjects.")]
    [SerializeField] private List<QuestData> allQuests;
    [Tooltip("All possible memory fragments in the game. These are ScriptableObjects.")]
    [SerializeField] private List<MemoryFragmentData> allMemoryFragments;

    // Internal state management for quests
    private Dictionary<string, QuestProgress> _activeQuests = new Dictionary<string, QuestProgress>();
    private HashSet<string> _completedQuests = new HashSet<string>();
    private HashSet<string> _unlockedMemoryFragments = new HashSet<string>();

    // Events for other systems to subscribe to
    public static event UnityAction<List<QuestData>> OnQuestProgressed; // Provides a list of active quests for UI update
    public static event UnityAction<MemoryFragmentData> OnMemoryFragmentUnlocked;

    private void Awake()
    {
        if (uiManager == null) Debug.LogError("QuestManager: UIManager is not assigned.", this);
        if (playerStats == null) Debug.LogError("QuestManager: PlayerStats is not assigned.", this);
        if (saveLoadManager == null) Debug.LogError("QuestManager: SaveLoadManager is not assigned. Quest progress will not persist!", this);

        // Ensure all QuestData ScriptableObjects have unique IDs
        ValidateQuestIDs();
        ValidateMemoryFragmentIDs();
    }

    private void OnEnable()
    {
        // Subscribe to SaveLoadManager's events to load and provide quest data
        if (saveLoadManager != null)
        {
            saveLoadManager.OnLoadGameData += LoadQuestState;
            saveLoadManager.OnSaveGameDataRequest += GetQuestSaveData;
        }
    }

    private void OnDisable()
    {
        // Unsubscribe to prevent memory leaks
        if (saveLoadManager != null)
        {
            saveLoadManager.OnLoadGameData -= LoadQuestState;
            saveLoadManager.OnSaveGameDataRequest -= GetQuestSaveData;
        }
    }

    /// <summary>
    /// Starts a new quest. If the quest is already active or completed, it does nothing.
    /// </summary>
    /// <param name="quest">The QuestData ScriptableObject to start.</param>
    public void StartQuest(QuestData quest)
    {
        if (quest == null)
        {
            Debug.LogError("QuestManager: Attempted to start a null quest.");
            return;
        }
        if (_activeQuests.ContainsKey(quest.QuestID))
        {
            Debug.LogWarning($"QuestManager: Quest '{quest.QuestName}' is already active.");
            uiManager?.ShowMessage($"Quest '{quest.QuestName}' is already active.");
            return;
        }
        if (_completedQuests.Contains(quest.QuestID))
        {
            Debug.LogWarning($"QuestManager: Quest '{quest.QuestName}' has already been completed.");
            uiManager?.ShowMessage($"Quest '{quest.QuestName}' has already been completed.");
            return;
        }

        // Initialize new quest progress
        QuestProgress newProgress = new QuestProgress(quest.QuestID);
        foreach (var obj in quest.Objectives)
        {
            newProgress.ObjectiveStates[obj.ObjectiveID] = false; // All objectives start as incomplete
        }

        _activeQuests.Add(quest.QuestID, newProgress);
        quest.IsStarted = true; // Mark the original ScriptableObject as started for runtime reference

        Debug.Log($"Quest Started: {quest.QuestName}");
        uiManager?.ShowMessage($"Quest Started: {quest.QuestName}");
        UpdateQuestLogUI(); // Notify UI to update quest log
    }

    /// <summary>
    /// Completes a specific objective for a quest. This is typically called by a specific
    /// interaction or event that knows exactly which objective it's fulfilling.
    /// </summary>
    /// <param name="objective">The QuestObjective object that has been completed.</param>
    public void CompleteObjective(QuestObjective objective)
    {
        if (objective == null)
        {
            Debug.LogError("QuestManager: Attempted to complete a null objective.");
            return;
        }

        // Find the parent quest
        QuestData parentQuest = allQuests.FirstOrDefault(q => q.Objectives.Any(o => o.ObjectiveID == objective.ObjectiveID));

        if (parentQuest == null)
        {
            Debug.LogWarning($"QuestManager: Objective '{objective.Description}' not found in any known quest.");
            return;
        }

        ProgressQuest(parentQuest.QuestID, objective.ObjectiveID);
    }


    /// <summary>
    /// Progresses a specific objective within a quest. This is the primary method called by external systems.
    /// </summary>
    /// <param name="questID">The ID of the quest to progress.</param>
    /// <param name="objectiveID">The ID of the objective to mark as complete.</param>
    public void ProgressQuest(string questID, string objectiveID)
    {
        if (!_activeQuests.TryGetValue(questID, out QuestProgress progress))
        {
            Debug.LogWarning($"QuestManager: Cannot progress quest. Quest with ID '{questID}' is not active.");
            return;
        }

        if (!progress.ObjectiveStates.ContainsKey(objectiveID))
        {
            Debug.LogWarning($"QuestManager: Objective with ID '{objectiveID}' not found for quest '{questID}'.");
            return;
        }

        if (progress.ObjectiveStates[objectiveID])
        {
            Debug.LogWarning($"QuestManager: Objective '{objectiveID}' for quest '{questID}' is already completed.");
            return;
        }

        // Mark objective as complete
        progress.ObjectiveStates[objectiveID] = true;

        // Find the actual QuestData ScriptableObject and its objective for UI updates etc.
        QuestData questData = allQuests.FirstOrDefault(q => q.QuestID == questID);
        if (questData != null)
        {
            QuestObjective completedObjective = questData.Objectives.FirstOrDefault(o => o.ObjectiveID == objectiveID);
            if (completedObjective != null)
            {
                completedObjective.IsCompleted = true; // Update the runtime state of the ScriptableObject
                Debug.Log($"Quest Objective Completed: {questData.QuestName} - {completedObjective.Description}");
                uiManager?.ShowMessage($"Objective Completed: {completedObjective.Description}");
            }
        }

        // Check if the quest is now completed
        if (progress.ObjectiveStates.All(kv => kv.Value))
        {
            CompleteQuest(questID);
        }

        UpdateQuestLogUI(); // Notify UI to update quest log
    }

    /// <summary>
    /// Marks a quest as fully completed. Handles rewards and memory fragments.
    /// </summary>
    /// <param name="questID">The ID of the quest to complete.</param>
    private void CompleteQuest(string questID)
    {
        if (!_activeQuests.ContainsKey(questID))
        {
            Debug.LogWarning($"QuestManager: Cannot complete quest. Quest with ID '{questID}' is not active.");
            return;
        }

        // Move from active to completed
        _activeQuests.Remove(questID);
        _completedQuests.Add(questID);

        QuestData completedQuest = allQuests.FirstOrDefault(q => q.QuestID == questID);
        if (completedQuest != null)
        {
            completedQuest.IsCompleted = true; // Mark the original ScriptableObject as completed
            Debug.Log($"Quest Completed: {completedQuest.QuestName}");
            uiManager?.ShowMessage($"Quest Completed: {completedQuest.QuestName}!");

            // Unlock Memory Fragment if specified
            if (completedQuest.MemoryFragmentToUnlock != null)
            {
                UnlockMemoryFragment(completedQuest.MemoryFragmentToUnlock);
            }
        }
        else
        {
            Debug.LogError($"QuestManager: Completed quest with ID '{questID}' not found in allQuests list.");
        }

        UpdateQuestLogUI(); // Notify UI to update quest log
    }

    /// <summary>
    /// Unlocks a Memory Fragment, applies its stat boosts, and notifies the UI.
    /// </summary>
    /// <param name="fragment">The MemoryFragmentData to unlock.</param>
    public void UnlockMemoryFragment(MemoryFragmentData fragment)
    {
        if (fragment == null)
        {
            Debug.LogError("QuestManager: Attempted to unlock a null Memory Fragment.");
            return;
        }
        if (_unlockedMemoryFragments.Contains(fragment.FragmentID))
        {
            Debug.LogWarning($"QuestManager: Memory Fragment '{fragment.FragmentName}' is already unlocked.");
            return;
        }

        _unlockedMemoryFragments.Add(fragment.FragmentID);
        Debug.Log($"Memory Fragment Unlocked: {fragment.FragmentName}");

        // Apply stat boosts
        if (playerStats != null)
        {
            playerStats.ApplyMemoryFragmentBoost(fragment);
            Debug.Log($"Applied stat boosts from Memory Fragment: {fragment.FragmentName}");
        }

        // Notify UI to display the fragment
        OnMemoryFragmentUnlocked?.Invoke(fragment);
        uiManager?.DisplayMemoryFragment(fragment);
        uiManager?.ShowMessage($"New Memory Unlocked: {fragment.FragmentName}");
    }

    /// <summary>
    /// Returns a list of all currently active quests with their current progress.
    /// </summary>
    /// <returns>A list of QuestData objects representing active quests.</returns>
    public List<QuestData> GetActiveQuests()
    {
        List<QuestData> activeQuestsList = new List<QuestData>();
        foreach (var kvp in _activeQuests)
        {
            QuestData questData = allQuests.FirstOrDefault(q => q.QuestID == kvp.Key);
            if (questData != null)
            {
                // Create a runtime copy or ensure the ScriptableObject's runtime state is correct
                // For this implementation, we directly modify the SO's IsCompleted state and Objective's IsCompleted state.
                // This assumes SOs are loaded once and their runtime states are managed.
                foreach (var obj in questData.Objectives)
                {
                    kvp.Value.ObjectiveStates.TryGetValue(obj.ObjectiveID, out obj.IsCompleted);
                }
                activeQuestsList.Add(questData);
            }
            else
            {
                Debug.LogWarning($"QuestManager: Active quest with ID '{kvp.Key}' not found in allQuests list.");
            }
        }
        return activeQuestsList;
    }

    /// <summary>
    /// Retrieves a QuestData ScriptableObject by its unique ID.
    /// </summary>
    /// <param name="questID">The ID of the quest to find.</param>
    /// <returns>The QuestData ScriptableObject if found, otherwise null.</returns>
    public QuestData GetQuest(string questID)
    {
        return allQuests.FirstOrDefault(q => q.QuestID == questID);
    }

    /// <summary>
    /// Retrieves a MemoryFragmentData ScriptableObject by its unique ID.
    /// </summary>
    /// <param name="fragmentID">The ID of the memory fragment to find.</param>
    /// <returns>The MemoryFragmentData ScriptableObject if found, otherwise null.</returns>
    public MemoryFragmentData GetMemoryFragment(string fragmentID)
    {
        return allMemoryFragments.FirstOrDefault(mf => mf.FragmentID == fragmentID);
    }

    /// <summary>
    /// Helper to notify the UIManager to refresh its quest log display.
    /// </summary>
    private void UpdateQuestLogUI()
    {
        OnQuestProgressed?.Invoke(GetActiveQuests());
    }

    /// <summary>
    /// Ensures all QuestData ScriptableObjects have unique IDs. Assigns new ones if duplicates or empty.
    /// </summary>
    private void ValidateQuestIDs()
    {
        if (allQuests == null) return;
        HashSet<string> seenIds = new HashSet<string>();
        foreach (var quest in allQuests)
        {
            if (quest == null) continue;
            if (string.IsNullOrEmpty(quest.QuestID) || seenIds.Contains(quest.QuestID))
            {
                Debug.LogWarning($"Quest '{quest.QuestName}' had duplicate or empty ID. Assigning new one.");
                quest.QuestID = Guid.NewGuid().ToString();
            }
            seenIds.Add(quest.QuestID);

            // Validate objective IDs within the quest
            HashSet<string> seenObjectiveIds = new HashSet<string>();
            foreach (var objective in quest.Objectives)
            {
                if (string.IsNullOrEmpty(objective.ObjectiveID) || seenObjectiveIds.Contains(objective.ObjectiveID))
                {
                    Debug.LogWarning($"Objective '{objective.Description}' in quest '{quest.QuestName}' had duplicate or empty ID. Assigning new one.");
                    objective.ObjectiveID = Guid.NewGuid().ToString();
                }
                seenObjectiveIds.Add(objective.ObjectiveID);
            }
        }
    }

    /// <summary>
    /// Ensures all MemoryFragmentData ScriptableObjects have unique IDs. Assigns new ones if duplicates or empty.
    /// </summary>
    private void ValidateMemoryFragmentIDs()
    {
        if (allMemoryFragments == null) return;
        HashSet<string> seenIds = new HashSet<string>();
        foreach (var fragment in allMemoryFragments)
        {
            if (fragment == null) continue;
            if (string.IsNullOrEmpty(fragment.FragmentID) || seenIds.Contains(fragment.FragmentID))
            {
                Debug.LogWarning($"Memory Fragment '{fragment.FragmentName}' had duplicate or empty ID. Assigning new one.");
                fragment.FragmentID = Guid.NewGuid().ToString();
            }
            seenIds.Add(fragment.FragmentID);
        }
    }

    // --- Save/Load Integration ---

    // Serializable class to hold quest progress for persistence
    [System.Serializable]
    public class QuestSaveData
    {
        public List<QuestProgressEntry> activeQuests = new List<QuestProgressEntry>();
        public List<string> completedQuestIDs = new List<string>();
        public List<string> unlockedMemoryFragmentIDs = new List<string>();

        [System.Serializable]
        public class QuestProgressEntry
        {
            public string questID;
            public Dictionary<string, bool> objectiveStates; // Key: objectiveID, Value: isCompleted

            public QuestProgressEntry(string qID, Dictionary<string, bool> objStates)
            {
                questID = qID;
                objectiveStates = objStates;
            }
        }
    }

    // Internal helper class to manage runtime quest progress
    [System.Serializable]
    private class QuestProgress
    {
        public string QuestID;
        public Dictionary<string, bool> ObjectiveStates;

        public QuestProgress(string questID)
        {
            QuestID = questID;
            ObjectiveStates = new Dictionary<string, bool>();
        }
    }

    /// <summary>
    /// Provides the current quest state for saving.
    /// Called by SaveLoadManager.
    /// </summary>
    /// <returns>An object containing all relevant quest data.</returns>
    public object GetQuestSaveData()
    {
        QuestSaveData saveData = new QuestSaveData();

        // Save active quests
        foreach (var kvp in _activeQuests)
        {
            saveData.activeQuests.Add(new QuestSaveData.QuestProgressEntry(kvp.Key, kvp.Value.ObjectiveStates));
        }

        // Save completed quests
        saveData.completedQuestIDs.AddRange(_completedQuests);

        // Save unlocked memory fragments
        saveData.unlockedMemoryFragmentIDs.AddRange(_unlockedMemoryFragments);

        Debug.Log("Quest state prepared for saving.");
        return saveData;
    }

    /// <summary>
    /// Loads the quest state from saved data.
    /// Called by SaveLoadManager.
    /// </summary>
    /// <param name="data">The quest save data object.</param>
    public void LoadQuestState(object data)
    {
        if (data is QuestSaveData saveData)
        {
            _activeQuests.Clear();
            _completedQuests.Clear();
            _unlockedMemoryFragments.Clear();

            // Reset all quests' runtime states before loading
            foreach (var quest in allQuests)
            {
                if (quest != null)
                {
                    quest.ResetQuestState();
                }
            }

            // Load active quests
            foreach (var entry in saveData.activeQuests)
            {
                QuestData questData = GetQuest(entry.questID);
                if (questData != null)
                {
                    QuestProgress newProgress = new QuestProgress(entry.questID)
                    {
                        ObjectiveStates = entry.objectiveStates
                    };
                    _activeQuests.Add(entry.questID, newProgress);
                    questData.IsStarted = true; // Mark as started

                    // Update runtime state of objectives in the ScriptableObject
                    foreach (var obj in questData.Objectives)
                    {
                        if (entry.objectiveStates.TryGetValue(obj.ObjectiveID, out bool isCompleted))
                        {
                            obj.IsCompleted = isCompleted;
                        }
                    }
                }
                else
                {
                    Debug.LogWarning($"QuestManager: Failed to load active quest with ID {entry.questID}. Quest definition not found.");
                }
            }

            // Load completed quests
            foreach (string questID in saveData.completedQuestIDs)
            {
                QuestData questData = GetQuest(questID);
                if (questData != null)
                {
                    _completedQuests.Add(questID);
                    questData.IsCompleted = true; // Mark as completed
                    // Also mark all objectives as completed for completed quests
                    foreach (var obj in questData.Objectives)
                    {
                        obj.IsCompleted = true;
                    }
                }
                else
                {
                    Debug.LogWarning($"QuestManager: Failed to load completed quest with ID {questID}. Quest definition not found.");
                }
            }

            // Load unlocked memory fragments
            foreach (string fragmentID in saveData.unlockedMemoryFragmentIDs)
            {
                MemoryFragmentData fragmentData = GetMemoryFragment(fragmentID);
                if (fragmentData != null)
                {
                    _unlockedMemoryFragments.Add(fragmentID);
                    // Re-apply stat boosts from previously unlocked fragments, if necessary.
                    // This can be tricky if boosts are cumulative or need specific timing.
                    // For simplicity, we assume PlayerStats can handle re-application idempotently.
                    if (playerStats != null)
                    {
                        playerStats.ApplyMemoryFragmentBoost(fragmentData);
                    }
                }
                else
                {
                    Debug.LogWarning($"QuestManager: Failed to load memory fragment with ID {fragmentID}. Fragment definition not found.");
                }
            }

            Debug.Log("Quest and Memory Fragment states loaded successfully.");
            UpdateQuestLogUI(); // Refresh UI after loading
        }
        else if (data != null)
        {
            Debug.LogError($"QuestManager: Invalid data type for loading quest state. Expected QuestSaveData, got {data.GetType().Name}.");
        }
        else
        {
            Debug.Log("QuestManager: No quest save data provided, initializing empty quest state.");
            _activeQuests.Clear();
            _completedQuests.Clear();
            _unlockedMemoryFragments.Clear();
            // Ensure all quests are reset to their initial non-started state
            foreach (var quest in allQuests)
            {
                if (quest != null)
                {
                    quest.ResetQuestState();
                }
            }
            UpdateQuestLogUI();
        }
    }
}