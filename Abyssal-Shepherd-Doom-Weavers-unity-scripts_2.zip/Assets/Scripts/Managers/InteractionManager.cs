using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;
using System;

public interface IInteractable
{
    /// <summary>
    /// Performs the primary interaction action for this object.
    /// </summary>
    /// <param name="interactor">The GameObject that initiated the interaction (e.g., the player).</param>
    void Interact(GameObject interactor);

    /// <summary>
    /// Gets a string representation of the interaction prompt (e.g., "Pick up", "Talk to").
    /// </summary>
    /// <returns>The interaction prompt string.</returns>
    string GetInteractionPrompt();
}

public class InteractionManager : MonoBehaviour
{
    // Dependencies
    [SerializeField] private InventoryManager inventoryManager;
    [SerializeField] private QuestManager questManager;
    [SerializeField] private CraftingManager craftingManager;
    [SerializeField] private UIManager uiManager;

    private IInteractable _currentInteractable;

    // Event to notify UIManager about interaction prompts
    // Parameter: string message (the prompt text), bool isAvailable (if interaction is possible)
    public UnityEvent<string, bool> OnInteractionPromptChanged;

    private void Awake()
    {
        if (inventoryManager == null) Debug.LogError("InventoryManager not assigned to InteractionManager.", this);
        if (questManager == null) Debug.LogError("QuestManager not assigned to InteractionManager.", this);
        if (craftingManager == null) Debug.LogError("CraftingManager not assigned to InteractionManager.", this);
        if (uiManager == null) Debug.LogError("UIManager not assigned to InteractionManager.", this);

        OnInteractionPromptChanged ??= new UnityEvent<string, bool>();
    }

    /// <summary>
    /// Handles the interaction logic when the player activates the 'Interact' action.
    /// This method is called by PlayerController when an interactable object is found.
    /// </summary>
    /// <param name="interactedObject">The GameObject that was interacted with.</param>
    public void HandleInteraction(GameObject interactedObject)
    {
        if (interactedObject == null)
        {
            Debug.LogWarning("InteractionManager: Attempted to interact with a null object.");
            return;
        }

        IInteractable interactable = interactedObject.GetComponent<IInteractable>();
        if (interactable != null)
        {
            interactable.Interact(this.gameObject); // Pass InteractionManager's GameObject as interactor for context
            ClearInteractable(); // Clear prompt after interaction
        }
        else
        {
            Debug.LogWarning($"InteractionManager: Object {interactedObject.name} does not implement IInteractable.");
        }
    }

    /// <summary>
    /// Sets the currently detected interactable object and updates the UI prompt.
    /// This method is called by PlayerController.
    /// </summary>
    /// <param name="interactable">The IInteractable object currently in range.</param>
    public void SetInteractable(IInteractable interactable)
    {
        if (_currentInteractable != interactable)
        {
            _currentInteractable = interactable;
            if (_currentInteractable != null)
            {
                OnInteractionPromptChanged.Invoke(_currentInteractable.GetInteractionPrompt(), true);
            }
            else
            {
                OnInteractionPromptChanged.Invoke(string.Empty, false); // Clear prompt
            }
        }
    }

    /// <summary>
    /// Clears the currently detected interactable object and hides the UI prompt.
    /// This method is called by PlayerController when no interactable is in range.
    /// </summary>
    public void ClearInteractable()
    {
        if (_currentInteractable != null)
        {
            _currentInteractable = null;
            OnInteractionPromptChanged.Invoke(string.Empty, false);
        }
    }

    // --- Helper methods for common interaction types, called by IInteractable implementations ---
    // These methods provide the business logic for specific interaction types,
    // allowing IInteractable implementations to simply call them.

    /// <summary>
    /// Handles picking up an item.
    /// </summary>
    /// <param name="itemData">The data of the item to pick up.</param>
    /// <param name="quantity">The quantity of the item.</param>
    /// <param name="interactedGameObject">The GameObject that was picked up (to be destroyed or disabled).</param>
    public void HandleItemPickup(InventoryItemData itemData, int quantity, GameObject interactedGameObject)
    {
        if (inventoryManager == null)
        {
            Debug.LogError("InteractionManager: InventoryManager is not assigned, cannot pick up item.");
            return;
        }
        if (itemData == null)
        {
            Debug.LogWarning("InteractionManager: Attempted to pick up a null item.");
            return;
        }
        if (quantity <= 0)
        {
            Debug.LogWarning($"InteractionManager: Attempted to pick up item {itemData.ItemName} with non-positive quantity {quantity}.");
            return;
        }

        inventoryManager.AddItem(itemData, quantity);
        uiManager?.ShowMessage($"Picked up {quantity}x {itemData.ItemName}.");
        Destroy(interactedGameObject); // Or disable, depending on pooling strategy
    }

    /// <summary>
    /// Handles interaction with an NPC.
    /// </summary>
    /// <param name="npcName">The name of the NPC.</param>
    /// <param name="dialogueID">The ID of the dialogue to start.</param>
    public void HandleNPCDialogue(string npcName, string dialogueID)
    {
        // In a real game, this would interface with a DialogueManager.
        // For now, we'll just show a message.
        uiManager?.ShowMessage($"Talking to {npcName}... (Dialogue ID: {dialogueID})");

        // Example: Check for quests related to this NPC
        // questManager?.CheckQuestProgressForNPC(npcName);
    }

    /// <summary>
    /// Handles interaction with a workbench.
    /// </summary>
    /// <param name="workbenchType">The type of workbench.</param>
    public void HandleWorkbenchInteraction(WorkbenchType workbenchType)
    {
        if (craftingManager == null)
        {
            Debug.LogError("InteractionManager: CraftingManager is not assigned, cannot use workbench.");
            return;
        }
        if (uiManager == null)
        {
            Debug.LogError("InteractionManager: UIManager is not assigned, cannot open crafting UI.");
            return;
        }

        craftingManager.SetCurrentWorkbench(workbenchType);
        uiManager.OpenCrafting();
        uiManager?.ShowMessage($"Opened {workbenchType} Workbench.");
    }

    /// <summary>
    /// Handles interaction with a generic quest object.
    /// </summary>
    /// <param name="questID">The ID of the quest this object relates to.</param>
    /// <param name="objectiveID">The ID of the objective to progress.</param>
    public void HandleQuestObjectInteraction(string questID, string objectiveID)
    {
        if (questManager == null)
        {
            Debug.LogError("InteractionManager: QuestManager is not assigned, cannot progress quest.");
            return;
        }

        questManager.ProgressQuest(questID, objectiveID);
        uiManager?.ShowMessage($"Quest objective updated: {questID} - {objectiveID}");
    }
}