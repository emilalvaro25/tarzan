// Required Packages:
// - com.unity.ugui
// - com.unity.textmeshpro

using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using System;

public class UIManager : MonoBehaviour
{
    [Header("HUD Elements")]
    [SerializeField] private Slider healthSlider;
    [SerializeField] private TextMeshProUGUI healthText;
    [SerializeField] private Slider staminaSlider;
    [SerializeField] private TextMeshProUGUI staminaText;
    [SerializeField] private Slider hungerSlider;
    [SerializeField] private TextMeshProUGUI hungerText;
    [SerializeField] private Slider thirstSlider;
    [SerializeField] private TextMeshProUGUI thirstText;
    [SerializeField] private Slider sanitySlider;
    [SerializeField] private TextMeshProUGUI sanityText;
    [SerializeField] private GameObject hudPanel;

    [Header("Inventory UI")]
    [SerializeField] private GameObject inventoryPanel;
    [SerializeField] private Transform inventoryContentParent;
    [SerializeField] private GameObject inventoryItemPrefab; // UI prefab for an inventory item slot
    [SerializeField] private TextMeshProUGUI inventoryDescriptionText;
    [SerializeField] private Button useItemButton;
    [SerializeField] private Button dropItemButton;
    [SerializeField] private Button inventoryCraftingButton; // Button to switch to crafting view
    private InventoryItemData _selectedInventoryItem;
    private Dictionary<InventoryItemData, GameObject> _inventoryItemUIElements = new Dictionary<InventoryItemData, GameObject>();

    [Header("Crafting UI")]
    [SerializeField] private GameObject craftingPanel;
    [SerializeField] private Transform craftingContentParent;
    [SerializeField] private GameObject craftingRecipePrefab; // UI prefab for a crafting recipe slot
    [SerializeField] private TextMeshProUGUI craftingDescriptionText;
    [SerializeField] private Button craftButton;
    [SerializeField] private Button craftingInventoryButton; // Button to switch to inventory view
    private CraftingBlueprint _selectedCraftingBlueprint;
    private Dictionary<CraftingBlueprint, GameObject> _craftingRecipeUIElements = new Dictionary<CraftingBlueprint, GameObject>();


    [Header("Quest Log UI")]
    [SerializeField] private GameObject questLogPanel;
    [SerializeField] private Transform questLogContentParent;
    [SerializeField] private GameObject questEntryPrefab; // UI prefab for a quest entry

    [Header("Map UI")]
    [SerializeField] private GameObject mapPanel;
    // Add more map-specific UI elements here as needed

    [Header("Pause Menu UI")]
    [SerializeField] private GameObject pauseMenuPanel;
    [SerializeField] private Button resumeButton;
    [SerializeField] private Button saveGameButton;
    [SerializeField] private Button loadGameButton;
    [SerializeField] private Button settingsButton;
    [SerializeField] private Button exitButton;

    [Header("Save/Load UI")]
    [SerializeField] private GameObject saveLoadPanel;
    [SerializeField] private Transform saveSlotContentParent;
    [SerializeField] private GameObject saveSlotPrefab; // UI prefab for a save slot
    [SerializeField] private Button closeSaveLoadButton;
    private Dictionary<int, GameObject> _saveSlotUIElements = new Dictionary<int, GameObject>();


    [Header("Memory Fragment UI")]
    [SerializeField] private GameObject memoryFragmentPanel;
    [SerializeField] private RawImage memoryFragmentImage; // For video/cinematic memory fragments
    [SerializeField] private TextMeshProUGUI memoryFragmentTitle;
    [SerializeField] private TextMeshProUGUI memoryFragmentText;
    [SerializeField] private Button closeMemoryFragmentButton;
    // Potentially add a VideoPlayer component if video fragments are used
    private bool _isMemoryFragmentDisplaying = false;


    [Header("Message Overlay")]
    [SerializeField] private GameObject messageOverlayPanel;
    [SerializeField] private TextMeshProUGUI messageText;
    [SerializeField] private float messageDisplayDuration = 3f;
    private Coroutine _messageDisplayCoroutine;

    // References to other managers
    private PlayerController _playerController; // Assuming it exists and can be accessed for input
    private InventoryManager _inventoryManager;
    private QuestManager _questManager;
    private SaveLoadManager _saveLoadManager;
    private CraftingManager _craftingManager;

    private GameObject _currentOpenPanel;

    private void Awake()
    {
        // Find and assign manager references (ensure these managers are in the scene)
        _playerController = FindObjectOfType<PlayerController>();
        _inventoryManager = FindObjectOfType<InventoryManager>();
        _questManager = FindObjectOfType<QuestManager>();
        _saveLoadManager = FindObjectOfType<SaveLoadManager>();
        _craftingManager = FindObjectOfType<CraftingManager>();

        // Ensure all panels are initially closed
        CloseAllPanels();

        // Initialize UI buttons
        if (useItemButton) useItemButton.onClick.AddListener(OnUseItemButtonClicked);
        if (dropItemButton) dropItemButton.onClick.AddListener(OnDropItemButtonClicked);
        if (craftButton) craftButton.onClick.AddListener(OnCraftButtonClicked);
        if (inventoryCraftingButton) inventoryCraftingButton.onClick.AddListener(OpenCraftingPanelFromInventory);
        if (craftingInventoryButton) craftingInventoryButton.onClick.AddListener(OpenInventoryPanelFromCrafting);

        if (resumeButton) resumeButton.onClick.AddListener(OnResumeButtonClicked);
        if (saveGameButton) saveGameButton.onClick.AddListener(OnSaveGameButtonClicked);
        if (loadGameButton) loadGameButton.onClick.AddListener(OnLoadGameButtonClicked);
        if (exitButton) exitButton.onClick.AddListener(OnExitButtonClicked); // For desktop/web builds, otherwise application quit

        if (closeMemoryFragmentButton) closeMemoryFragmentButton.onClick.AddListener(CloseMemoryFragment);
        if (closeSaveLoadButton) closeSaveLoadButton.onClick.AddListener(CloseSaveLoadPanel);

        // Hide description and action buttons for inventory/crafting until an item/recipe is selected
        SetInventoryItemSelection(null);
        SetCraftingRecipeSelection(null);

        // Ensure message overlay is off
        if (messageOverlayPanel) messageOverlayPanel.SetActive(false);
    }

    private void OnEnable()
    {
        // Subscribe to events
        PlayerStats.OnStatChanged += UpdateHUD;
        InventoryManager.OnInventoryUpdated += UpdateInventoryUI;
        QuestManager.OnQuestProgressed += UpdateQuestLogUI;
        QuestManager.OnMemoryFragmentUnlocked += DisplayMemoryFragment;
        SaveLoadManager.OnGameSaved += ShowMessageForSaveLoad;
        SaveLoadManager.OnGameLoaded += ShowMessageForSaveLoad;
        SaveLoadManager.OnSaveSlotsQueried += UpdateSaveLoadPanel;
    }

    private void OnDisable()
    {
        // Unsubscribe from events to prevent memory leaks
        PlayerStats.OnStatChanged -= UpdateHUD;
        InventoryManager.OnInventoryUpdated -= UpdateInventoryUI;
        QuestManager.OnQuestProgressed -= UpdateQuestLogUI;
        QuestManager.OnMemoryFragmentUnlocked -= DisplayMemoryFragment;
        SaveLoadManager.OnGameSaved -= ShowMessageForSaveLoad;
        SaveLoadManager.OnGameLoaded -= ShowMessageForSaveLoad;
        SaveLoadManager.OnSaveSlotsQueried -= UpdateSaveLoadPanel;
    }

    // --- Main UI Panel Management ---
    private void CloseAllPanels()
    {
        hudPanel.SetActive(true); // HUD is generally always active unless a major menu is open
        inventoryPanel.SetActive(false);
        craftingPanel.SetActive(false);
        questLogPanel.SetActive(false);
        mapPanel.SetActive(false);
        pauseMenuPanel.SetActive(false);
        memoryFragmentPanel.SetActive(false);
        saveLoadPanel.SetActive(false);

        // If a panel was open, set currentOpenPanel to null
        _currentOpenPanel = null;
        SetGamePaused(false);
    }

    private void OpenPanel(GameObject panelToOpen)
    {
        if (_isMemoryFragmentDisplaying) return; // Block opening other panels while memory fragment is active

        if (_currentOpenPanel != null && _currentOpenPanel != panelToOpen)
        {
            _currentOpenPanel.SetActive(false);
        }

        panelToOpen.SetActive(true);
        _currentOpenPanel = panelToOpen;
        hudPanel.SetActive(false); // Hide HUD when a major panel is open
        SetGamePaused(true);
    }

    private void ClosePanel(GameObject panelToClose)
    {
        if (panelToClose != null)
        {
            panelToClose.SetActive(false);
            if (_currentOpenPanel == panelToClose)
            {
                _currentOpenPanel = null;
            }
        }
        if (_currentOpenPanel == null && !_isMemoryFragmentDisplaying)
        {
            hudPanel.SetActive(true);
            SetGamePaused(false);
        }
    }

    private void SetGamePaused(bool isPaused)
    {
        Time.timeScale = isPaused ? 0f : 1f;
        // Potentially disable PlayerController input here
        if (_playerController)
        {
            _playerController.SetInputEnabled(!isPaused);
        }
    }

    // --- Public Methods for External Calls (e.g., PlayerController, InputManager) ---
    public void ToggleInventory()
    {
        if (inventoryPanel.activeSelf) ClosePanel(inventoryPanel);
        else OpenInventory();
    }

    public void ToggleQuestLog()
    {
        if (questLogPanel.activeSelf) ClosePanel(questLogPanel);
        else OpenQuestLog();
    }

    public void ToggleMap()
    {
        if (mapPanel.activeSelf) ClosePanel(mapPanel);
        else OpenMap();
    }

    public void TogglePauseMenu()
    {
        if (pauseMenuPanel.activeSelf) ClosePanel(pauseMenuPanel);
        else OpenPauseMenu();
    }


    // --- HUD Management ---
    public void UpdateHUD(PlayerStatType statType, float value)
    {
        Slider targetSlider = null;
        TextMeshProUGUI targetText = null;

        switch (statType)
        {
            case PlayerStatType.Health:
                targetSlider = healthSlider;
                targetText = healthText;
                break;
            case PlayerStatType.Stamina:
                targetSlider = staminaSlider;
                targetText = staminaText;
                break;
            case PlayerStatType.Hunger:
                targetSlider = hungerSlider;
                targetText = hungerText;
                break;
            case PlayerStatType.Thirst:
                targetSlider = thirstSlider;
                targetText = thirstText;
                break;
            case PlayerStatType.Sanity:
                targetSlider = sanitySlider;
                targetText = sanityText;
                break;
            default:
                Debug.LogWarning($"UIManager: Unhandled PlayerStatType for HUD update: {statType}");
                return;
        }

        if (targetSlider != null)
        {
            targetSlider.value = value;
        }
        if (targetText != null)
        {
            targetText.text = Mathf.RoundToInt(value).ToString();
        }
    }

    // --- Inventory Management ---
    public void OpenInventory()
    {
        OpenPanel(inventoryPanel);
        UpdateInventoryUI(_inventoryManager?.GetAllItems()); // Request current items from InventoryManager
        SetInventoryItemSelection(null); // Clear previous selection
    }

    public void CloseInventory()
    {
        ClosePanel(inventoryPanel);
    }

    private void UpdateInventoryUI(Dictionary<InventoryItemData, int> items)
    {
        // Clear existing UI elements, but first remove them from the dictionary
        foreach (var uiElement in _inventoryItemUIElements.Values)
        {
            Destroy(uiElement);
        }
        _inventoryItemUIElements.Clear();

        if (inventoryItemPrefab == null || inventoryContentParent == null)
        {
            Debug.LogError("InventoryItemPrefab or InventoryContentParent is not assigned in UIManager.");
            return;
        }

        if (items == null) return;

        foreach (var entry in items)
        {
            InventoryItemData itemData = entry.Key;
            int quantity = entry.Value;

            GameObject itemUI = Instantiate(inventoryItemPrefab, inventoryContentParent);
            TextMeshProUGUI nameText = itemUI.transform.Find("NameText")?.GetComponent<TextMeshProUGUI>();
            TextMeshProUGUI quantityText = itemUI.transform.Find("QuantityText")?.GetComponent<TextMeshProUGUI>();
            Button itemButton = itemUI.GetComponent<Button>();

            if (nameText) nameText.text = itemData.ItemName;
            if (quantityText) quantityText.text = $"x{quantity}";
            if (itemButton)
            {
                itemButton.onClick.AddListener(() => SetInventoryItemSelection(itemData));
            }

            _inventoryItemUIElements.Add(itemData, itemUI);
        }

        SetInventoryItemSelection(_selectedInventoryItem); // Re-apply selection if item still exists
    }

    private void SetInventoryItemSelection(InventoryItemData itemData)
    {
        _selectedInventoryItem = itemData;
        bool hasSelection = itemData != null;

        if (inventoryDescriptionText)
        {
            inventoryDescriptionText.text = hasSelection ? itemData.ItemDescription : "Select an item to see its details.";
        }
        if (useItemButton) useItemButton.interactable = hasSelection && itemData.CanBeUsed;
        if (dropItemButton) dropItemButton.interactable = hasSelection;

        // Visually highlight the selected item
        foreach (var entry in _inventoryItemUIElements)
        {
            if (entry.Value.TryGetComponent<Image>(out var image))
            {
                image.color = (entry.Key == itemData) ? Color.yellow : Color.white; // Or use a proper sprite/background
            }
        }
    }

    private void OnUseItemButtonClicked()
    {
        if (_selectedInventoryItem != null && _inventoryManager != null)
        {
            _inventoryManager.UseItem(_selectedInventoryItem);
            SetInventoryItemSelection(null); // Clear selection after use
        }
    }

    private void OnDropItemButtonClicked()
    {
        if (_selectedInventoryItem != null && _inventoryManager != null)
        {
            _inventoryManager.RemoveItem(_selectedInventoryItem, 1); // Drop one item
            SetInventoryItemSelection(null); // Clear selection after drop
        }
    }

    private void OpenCraftingPanelFromInventory()
    {
        CloseInventory();
        OpenCrafting();
    }

    private void OpenInventoryPanelFromCrafting()
    {
        CloseCrafting();
        OpenInventory();
    }

    // --- Crafting Management ---
    public void OpenCrafting()
    {
        OpenPanel(craftingPanel);
        UpdateCraftingUI(_craftingManager?.GetAvailableBlueprints(WorkbenchType.None)); // Request blueprints, assuming no specific workbench for now
        SetCraftingRecipeSelection(null); // Clear previous selection
    }

    public void CloseCrafting()
    {
        ClosePanel(craftingPanel);
    }

    public void UpdateCraftingUI(List<CraftingBlueprint> blueprints)
    {
        // Clear existing UI elements
        foreach (var uiElement in _craftingRecipeUIElements.Values)
        {
            Destroy(uiElement);
        }
        _craftingRecipeUIElements.Clear();

        if (craftingRecipePrefab == null || craftingContentParent == null)
        {
            Debug.LogError("CraftingRecipePrefab or CraftingContentParent is not assigned in UIManager.");
            return;
        }

        if (blueprints == null) return;

        foreach (CraftingBlueprint blueprint in blueprints)
        {
            GameObject recipeUI = Instantiate(craftingRecipePrefab, craftingContentParent);
            TextMeshProUGUI nameText = recipeUI.transform.Find("NameText")?.GetComponent<TextMeshProUGUI>();
            Button recipeButton = recipeUI.GetComponent<Button>();

            if (nameText) nameText.text = blueprint.ResultItem.ItemName;
            if (recipeButton)
            {
                recipeButton.onClick.AddListener(() => SetCraftingRecipeSelection(blueprint));
            }
            _craftingRecipeUIElements.Add(blueprint, recipeUI);
        }

        SetCraftingRecipeSelection(_selectedCraftingBlueprint); // Re-apply selection if blueprint still exists
    }

    private void SetCraftingRecipeSelection(CraftingBlueprint blueprint)
    {
        _selectedCraftingBlueprint = blueprint;
        bool hasSelection = blueprint != null;

        if (craftingDescriptionText)
        {
            string description = hasSelection ? $"Crafts: {blueprint.ResultItem.ItemName}\nRequires:\n" : "Select a recipe to see its requirements.";
            if (hasSelection)
            {
                foreach (var requirement in blueprint.RequiredItems)
                {
                    description += $"- {requirement.Key.ItemName} x{requirement.Value}\n";
                }
            }
            craftingDescriptionText.text = description;
        }

        if (craftButton)
        {
            craftButton.interactable = hasSelection && (_craftingManager?.CanCraft(blueprint) ?? false);
        }

        // Visually highlight the selected recipe
        foreach (var entry in _craftingRecipeUIElements)
        {
            if (entry.Value.TryGetComponent<Image>(out var image))
            {
                image.color = (entry.Key == blueprint) ? Color.yellow : Color.white;
            }
        }
    }

    private void OnCraftButtonClicked()
    {
        if (_selectedCraftingBlueprint != null && _craftingManager != null && _craftingManager.CanCraft(_selectedCraftingBlueprint))
        {
            _craftingManager.CraftItem(_selectedCraftingBlueprint);
            SetCraftingRecipeSelection(_selectedCraftingBlueprint); // Re-evaluate interactability after crafting
            ShowMessage($"Crafted {_selectedCraftingBlueprint.ResultItem.ItemName}!");
        }
    }


    // --- Quest Log Management ---
    public void OpenQuestLog()
    {
        OpenPanel(questLogPanel);
        UpdateQuestLogUI(_questManager?.GetActiveQuests());
    }

    public void CloseQuestLog()
    {
        ClosePanel(questLogPanel);
    }

    public void UpdateQuestLogUI(List<QuestData> activeQuests)
    {
        // Clear existing UI elements
        foreach (Transform child in questLogContentParent)
        {
            Destroy(child.gameObject);
        }

        if (questEntryPrefab == null || questLogContentParent == null)
        {
            Debug.LogError("QuestEntryPrefab or QuestLogContentParent is not assigned in UIManager.");
            return;
        }

        if (activeQuests == null || activeQuests.Count == 0)
        {
            // Display a message indicating no active quests
            GameObject noQuestsMessage = new GameObject("No Quests Message");
            noQuestsMessage.transform.SetParent(questLogContentParent);
            TextMeshProUGUI messageText = noQuestsMessage.AddComponent<TextMeshProUGUI>();
            messageText.text = "No active quests at the moment.";
            messageText.alignment = TextAlignmentOptions.Center;
            messageText.fontSize = 24;
            return;
        }

        foreach (QuestData quest in activeQuests)
        {
            GameObject questUI = Instantiate(questEntryPrefab, questLogContentParent);
            TextMeshProUGUI titleText = questUI.transform.Find("TitleText")?.GetComponent<TextMeshProUGUI>();
            TextMeshProUGUI descriptionText = questUI.transform.Find("DescriptionText")?.GetComponent<TextMeshProUGUI>();
            Transform objectivesParent = questUI.transform.Find("ObjectivesParent"); // Assuming there's a child for objectives

            if (titleText) titleText.text = quest.QuestName;
            if (descriptionText) descriptionText.text = quest.QuestDescription;

            if (objectivesParent)
            {
                foreach (Transform child in objectivesParent)
                {
                    Destroy(child.gameObject);
                }

                foreach (QuestObjective objective in quest.Objectives)
                {
                    GameObject objectiveTextGO = new GameObject("Objective Text");
                    objectiveTextGO.transform.SetParent(objectivesParent);
                    TextMeshProUGUI objectiveText = objectiveTextGO.AddComponent<TextMeshProUGUI>();
                    objectiveText.text = $"- {objective.Description} [{(objective.IsCompleted ? "Completed" : "Active")}]";
                    objectiveText.color = objective.IsCompleted ? Color.green : Color.white;
                    objectiveText.fontSize = 18;
                }
            }
        }
    }

    // --- Map Management ---
    public void OpenMap()
    {
        OpenPanel(mapPanel);
        // Additional map initialization/update logic here
    }

    public void CloseMap()
    {
        ClosePanel(mapPanel);
    }

    // --- Pause Menu Management ---
    public void OpenPauseMenu()
    {
        OpenPanel(pauseMenuPanel);
    }

    public void ClosePauseMenu()
    {
        ClosePanel(pauseMenuPanel);
    }

    private void OnResumeButtonClicked()
    {
        ClosePauseMenu();
    }

    private void OnSaveGameButtonClicked()
    {
        if (_saveLoadManager)
        {
            OpenSaveLoadPanel(SaveLoadManager.SaveLoadMode.Save);
        }
        else
        {
            ShowMessage("SaveLoadManager not found!");
        }
    }

    private void OnLoadGameButtonClicked()
    {
        if (_saveLoadManager)
        {
            OpenSaveLoadPanel(SaveLoadManager.SaveLoadMode.Load);
        }
        else
        {
            ShowMessage("SaveLoadManager not found!");
        }
    }

    private void OnExitButtonClicked()
    {
        // Depending on platform, this might be Application.Quit() or a scene load to main menu
        ShowMessage("Exiting game...");
        // In a web build, Application.Quit() might not do anything. For web, you might redirect or simply stop.
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // --- Save/Load UI ---
    private SaveLoadManager.SaveLoadMode _currentSaveLoadMode;

    public void OpenSaveLoadPanel(SaveLoadManager.SaveLoadMode mode)
    {
        OpenPanel(saveLoadPanel);
        _currentSaveLoadMode = mode;
        _saveLoadManager?.QuerySaveSlots(); // Request save slot data
    }

    public void CloseSaveLoadPanel()
    {
        ClosePanel(saveLoadPanel);
    }

    public void UpdateSaveLoadPanel(List<SaveSlotData> slots)
    {
        // Clear existing UI elements
        foreach (var uiElement in _saveSlotUIElements.Values)
        {
            Destroy(uiElement);
        }
        _saveSlotUIElements.Clear();

        if (saveSlotPrefab == null || saveSlotContentParent == null)
        {
            Debug.LogError("SaveSlotPrefab or SaveSlotContentParent is not assigned in UIManager.");
            return;
        }

        for (int i = 0; i < SaveLoadManager.MaxSaveSlots; i++)
        {
            int slotIndex = i; // Capture for lambda
            GameObject slotUI = Instantiate(saveSlotPrefab, saveSlotContentParent);
            TextMeshProUGUI slotNameText = slotUI.transform.Find("SlotNameText")?.GetComponent<TextMeshProUGUI>();
            TextMeshProUGUI detailsText = slotUI.transform.Find("DetailsText")?.GetComponent<TextMeshProUGUI>();
            Button slotButton = slotUI.GetComponent<Button>();

            SaveSlotData slotData = slots.Find(s => s.SlotIndex == slotIndex);
            bool hasData = slotData != null;

            if (slotNameText) slotNameText.text = $"Slot {slotIndex + 1}";
            if (detailsText) detailsText.text = hasData ? $"Last Save: {slotData.Timestamp:MM/dd/yyyy HH:mm}" : "Empty";
            if (slotButton)
            {
                slotButton.onClick.RemoveAllListeners(); // Clear previous listeners
                slotButton.onClick.AddListener(() => OnSaveSlotSelected(slotIndex, hasData));
                slotButton.interactable = _currentSaveLoadMode == SaveLoadManager.SaveLoadMode.Save || hasData; // Can always save, only load if data exists
            }
            _saveSlotUIElements.Add(slotIndex, slotUI);
        }
    }

    private void OnSaveSlotSelected(int slotIndex, bool hasData)
    {
        if (_saveLoadManager == null)
        {
            ShowMessage("SaveLoadManager not found!");
            return;
        }

        if (_currentSaveLoadMode == SaveLoadManager.SaveLoadMode.Save)
        {
            _saveLoadManager.SaveGame(slotIndex);
            CloseSaveLoadPanel();
            ClosePauseMenu();
        }
        else if (_currentSaveLoadMode == SaveLoadManager.SaveLoadMode.Load)
        {
            if (hasData)
            {
                _saveLoadManager.LoadGame(slotIndex);
                CloseSaveLoadPanel();
                ClosePauseMenu();
            }
            else
            {
                ShowMessage("No save data in this slot.");
            }
        }
    }

    private void ShowMessageForSaveLoad(bool success, string message)
    {
        ShowMessage(message);
    }


    // --- Memory Fragment Display ---
    public void DisplayMemoryFragment(MemoryFragmentData fragment)
    {
        if (fragment == null) return;

        _isMemoryFragmentDisplaying = true;
        OpenPanel(memoryFragmentPanel);
        SetGamePaused(true); // Pause game while memory fragment is displayed

        if (memoryFragmentTitle) memoryFragmentTitle.text = fragment.FragmentName;
        if (memoryFragmentText) memoryFragmentText.text = fragment.FragmentDescription; // Assuming Description field

        if (memoryFragmentImage)
        {
            // Placeholder for image/video. In a real scenario, you'd load a texture or set up a VideoPlayer.
            // For now, just hide it if no specific content is assigned.
            memoryFragmentImage.gameObject.SetActive(false);
            // If fragment had a Sprite/Texture property:
            // memoryFragmentImage.texture = fragment.FragmentVisual;
            // memoryFragmentImage.gameObject.SetActive(true);

            // If it were a video:
            // VideoPlayer videoPlayer = memoryFragmentPanel.GetComponentInChildren<VideoPlayer>();
            // if (videoPlayer && fragment.VideoClip) { videoPlayer.clip = fragment.VideoClip; videoPlayer.Play(); memoryFragmentImage.gameObject.SetActive(true); }
        }
    }

    public void CloseMemoryFragment()
    {
        // Stop any playing video if applicable
        // VideoPlayer videoPlayer = memoryFragmentPanel.GetComponentInChildren<VideoPlayer>();
        // if (videoPlayer) videoPlayer.Stop();

        ClosePanel(memoryFragmentPanel);
        _isMemoryFragmentDisplaying = false;
        // Resume game only if no other panel is open
        if (_currentOpenPanel == null)
        {
            SetGamePaused(false);
            hudPanel.SetActive(true);
        }
    }


    // --- General Message Overlay ---
    public void ShowMessage(string message)
    {
        if (messageOverlayPanel == null || messageText == null)
        {
            Debug.LogError("MessageOverlayPanel or MessageText not assigned in UIManager.");
            return;
        }

        if (_messageDisplayCoroutine != null)
        {
            StopCoroutine(_messageDisplayCoroutine);
        }

        messageText.text = message;
        messageOverlayPanel.SetActive(true);
        _messageDisplayCoroutine = StartCoroutine(HideMessageAfterDelay(messageDisplayDuration));
    }

    private System.Collections.IEnumerator HideMessageAfterDelay(float delay)
    {
        yield return new WaitForSecondsRealtime(delay); // Use Realtime to not be affected by Time.timeScale
        messageOverlayPanel.SetActive(false);
    }
}

// Dummy classes to satisfy UIManager dependencies (assuming these are ScriptableObjects or similar data structures)
// These would typically be defined in their respective manager files or a common data types folder.

[System.Serializable]
public class InventoryItemData // Matches the definition in InventoryManager
{
    public string ItemID;
    public string ItemName;
    public string ItemDescription;
    public bool CanBeUsed;
    public List<StatEffect> StatEffects; // For consumable items
}

[System.Serializable]
public class QuestData // Matches the definition in QuestManager
{
    public string QuestID;
    public string QuestName;
    public string QuestDescription;
    public List<QuestObjective> Objectives;
    public bool IsCompleted;
}

[System.Serializable]
public class QuestObjective // Matches the definition in QuestManager
{
    public string ObjectiveID;
    public string Description;
    public bool IsCompleted;
}

[System.Serializable]
public class MemoryFragmentData // Matches the definition in QuestManager
{
    public string FragmentID;
    public string FragmentName;
    public string FragmentDescription; // Added for display
    public List<StatEffect> StatBoosts;
    // public Sprite FragmentVisual; // Example for visual asset
    // public VideoClip VideoClip; // Example for video asset
}


[System.Serializable]
public class CraftingBlueprint // Matches the definition in CraftingManager
{
    public string BlueprintID;
    public InventoryItemData ResultItem; // The item produced
    public Dictionary<InventoryItemData, int> RequiredItems; // Items needed to craft
    public WorkbenchType RequiredWorkbench; // Type of workbench needed
}

public enum WorkbenchType // Matches the definition in CraftingManager
{
    None,
    Bamboo,
    Stone,
    Iron
}

[System.Serializable]
public class SaveSlotData // Matches the definition in SaveLoadManager
{
    public int SlotIndex;
    public DateTime Timestamp;
    public string PlayerLocation; // Example data to display
    // Add more summary data here if needed for UI
}