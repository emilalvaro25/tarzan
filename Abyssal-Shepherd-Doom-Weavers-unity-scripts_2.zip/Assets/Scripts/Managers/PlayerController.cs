// Required Packages:
// - com.unity.inputsystem

using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Events;
using System;

public class PlayerController : MonoBehaviour
{
    // Dependencies
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private InteractionManager interactionManager;
    [SerializeField] private InventoryManager inventoryManager;
    [SerializeField] private QuestManager questManager;
    [SerializeField] private WorldManager worldManager;

    [Header("Movement")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float sprintSpeedMultiplier = 1.5f;
    [SerializeField] private float rotationSpeed = 100f;
    [SerializeField] private float jumpForce = 5f;
    [SerializeField] private float jumpStaminaCost = 10f;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundCheckRadius = 0.2f;

    [Header("Camera Look")]
    [SerializeField] private float lookSensitivityX = 1f;
    [SerializeField] private float lookSensitivityY = 1f;
    [SerializeField] private float minPitch = -60f;
    [SerializeField] private float maxPitch = 90f;
    [SerializeField] private Transform cameraHolder;

    [Header("Interaction")]
    [SerializeField] private float interactionRange = 3f;
    [SerializeField] private LayerMask interactableLayer;

    [Header("Combat")]
    [SerializeField] private float attackStaminaCost = 15f;
    [SerializeField] private float blockStaminaCostPerSecond = 5f;
    [SerializeField] private float attackCooldown = 0.5f;
    [SerializeField] private LayerMask attackableLayer;

    // Internal State
    private Rigidbody rb;
    private Vector2 moveInput;
    private Vector2 lookInput;
    private bool isSprinting = false;
    private bool isJumping = false;
    private bool isBlocking = false;
    private float currentPitch = 0f;
    private float lastAttackTime = -Mathf.Infinity;

    // Events
    public UnityEvent OnPlayerAttack;
    public UnityEvent OnPlayerJump;
    public UnityEvent OnPlayerInteract;
    public UnityEvent OnPlayerBlockStart;
    public UnityEvent OnPlayerBlockEnd;
    public UnityEvent OnPlayerSprintStart;
    public UnityEvent OnPlayerSprintEnd;
    public UnityEvent OnPlayerMovementStart;
    public UnityEvent OnPlayerMovementEnd;


    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            Debug.LogError("PlayerController requires a Rigidbody component.", this);
            enabled = false;
            return;
        }

        if (playerStats == null) Debug.LogError("PlayerStats not assigned to PlayerController.", this);
        if (interactionManager == null) Debug.LogError("InteractionManager not assigned to PlayerController.", this);
        if (inventoryManager == null) Debug.LogError("InventoryManager not assigned to PlayerController.", this);
        if (questManager == null) Debug.LogError("QuestManager not assigned to PlayerController.", this);
        if (worldManager == null) Debug.LogError("WorldManager not assigned to PlayerController.", this);

        // Ensure events are initialized to prevent NullReferenceExceptions if no listeners
        OnPlayerAttack ??= new UnityEvent();
        OnPlayerJump ??= new UnityEvent();
        OnPlayerInteract ??= new UnityEvent();
        OnPlayerBlockStart ??= new UnityEvent();
        OnPlayerBlockEnd ??= new UnityEvent();
        OnPlayerSprintStart ??= new UnityEvent();
        OnPlayerSprintEnd ??= new UnityEvent();
        OnPlayerMovementStart ??= new UnityEvent();
        OnPlayerMovementEnd ??= new UnityEvent();

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        HandleLook(lookInput); // Camera look in Update for responsiveness

        // Detect potential interactables
        RaycastHit hit;
        if (Physics.SphereCast(cameraHolder.position, 0.2f, cameraHolder.forward, out hit, interactionRange, interactableLayer))
        {
            IInteractable interactable = hit.collider.GetComponent<IInteractable>();
            if (interactable != null)
            {
                interactionManager.SetInteractable(interactable);
            }
            else
            {
                interactionManager.ClearInteractable();
            }
        }
        else
        {
            interactionManager.ClearInteractable();
        }

        if (isBlocking)
        {
            playerStats.AdjustStamina(-blockStaminaCostPerSecond * Time.deltaTime);
        }

        // Check for movement start/end
        if (moveInput.magnitude > 0.1f && !playerIsMoving)
        {
            OnPlayerMovementStart.Invoke();
            playerIsMoving = true;
        }
        else if (moveInput.magnitude < 0.1f && playerIsMoving)
        {
            OnPlayerMovementEnd.Invoke();
            playerIsMoving = false;
        }
    }

    private bool playerIsMoving = false;

    private void FixedUpdate()
    {
        HandleMovement(moveInput); // Physics-based movement in FixedUpdate
    }

    // --- Input System Callbacks ---
    public void OnMove(InputAction.CallbackContext context)
    {
        moveInput = context.ReadValue<Vector2>();
    }

    public void OnLook(InputAction.CallbackContext context)
    {
        lookInput = context.ReadValue<Vector2>();
    }

    public void OnInteract(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            Interact();
        }
    }

    public void OnAttack(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            Attack();
        }
    }

    public void OnJump(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            Jump();
        }
    }

    public void OnBlockAim(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            BlockAim(true);
        }
        else if (context.canceled)
        {
            BlockAim(false);
        }
    }

    public void OnSprint(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            isSprinting = true;
            OnPlayerSprintStart.Invoke();
        }
        else if (context.canceled)
        {
            isSprinting = false;
            OnPlayerSprintEnd.Invoke();
        }
    }

    // --- Core Action Implementations ---

    /// <summary>
    /// Handles player character movement based on input.
    /// </summary>
    /// <param name="input">Normalized 2D input vector (e.g., from joystick or WASD).</param>
    public void HandleMovement(Vector2 input)
    {
        float currentSpeed = moveSpeed;
        if (isSprinting && playerStats.GetStat(PlayerStatType.Stamina) > 0)
        {
            currentSpeed *= sprintSpeedMultiplier;
            playerStats.AdjustStamina(-Time.fixedDeltaTime * (moveSpeed * sprintSpeedMultiplier * 0.1f)); // Small stamina drain for sprint
        }
        else if (isSprinting && playerStats.GetStat(PlayerStatType.Stamina) <= 0)
        {
            isSprinting = false; // Stop sprinting if stamina runs out
            OnPlayerSprintEnd.Invoke();
        }


        Vector3 forward = transform.forward * input.y;
        Vector3 right = transform.right * input.x;
        Vector3 moveDirection = (forward + right).normalized;

        if (moveDirection.magnitude > 0.01f)
        {
            rb.MovePosition(rb.position + moveDirection * currentSpeed * Time.fixedDeltaTime);
        }
    }

    /// <summary>
    /// Handles camera and player character rotation based on look input.
    /// </summary>
    /// <param name="input">2D input vector (e.g., from mouse or right stick).</param>
    public void HandleLook(Vector2 input)
    {
        // Rotate player horizontally
        float yaw = input.x * lookSensitivityX;
        transform.Rotate(Vector3.up * yaw);

        // Rotate camera vertically
        currentPitch -= input.y * lookSensitivityY;
        currentPitch = Mathf.Clamp(currentPitch, minPitch, maxPitch);
        cameraHolder.localEulerAngles = new Vector3(currentPitch, 0f, 0f);
    }

    /// <summary>
    /// Attempts to interact with an object in front of the player.
    /// </summary>
    public void Interact()
    {
        RaycastHit hit;
        if (Physics.SphereCast(cameraHolder.position, 0.2f, cameraHolder.forward, out hit, interactionRange, interactableLayer))
        {
            IInteractable interactable = hit.collider.GetComponent<IInteractable>();
            if (interactable != null)
            {
                interactionManager.HandleInteraction(hit.collider.gameObject);
                OnPlayerInteract.Invoke();
            }
        }
    }

    /// <summary>
    /// Initiates a player attack if conditions are met.
    /// </summary>
    public void Attack()
    {
        if (Time.time < lastAttackTime + attackCooldown) return;
        if (playerStats.GetStat(PlayerStatType.Stamina) < attackStaminaCost) return;

        playerStats.AdjustStamina(-attackStaminaCost);
        lastAttackTime = Time.time;
        OnPlayerAttack.Invoke();

        // Simple attack logic: hit objects in front
        // In a full game, this would involve animation events, collision detection with hitboxes, etc.
        Collider[] hitColliders = Physics.OverlapSphere(cameraHolder.position + cameraHolder.forward * 1f, 1f, attackableLayer);
        foreach (Collider hitCollider in hitColliders)
        {
            CreatureAI creature = hitCollider.GetComponent<CreatureAI>();
            if (creature != null)
            {
                creature.TakeDamage(10f); // Example damage value
            }
            else // Check if it's an environmental object that can be damaged or harvested
            {
                // For example, if you have a destructible object or harvestable resource component
                // DestructibleObject destructible = hitCollider.GetComponent<DestructibleObject>();
                // if (destructible != null) destructible.TakeDamage(10f);
                // HarvestableResource resource = hitCollider.GetComponent<HarvestableResource>();
                // if (resource != null) resource.Harvest();
            }
        }
    }

    /// <summary>
    /// Makes the player jump if on ground and has enough stamina.
    /// </summary>
    public void Jump()
    {
        bool isGrounded = Physics.CheckSphere(groundCheck.position, groundCheckRadius, groundLayer);
        if (isGrounded && playerStats.GetStat(PlayerStatType.Stamina) >= jumpStaminaCost)
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            playerStats.AdjustStamina(-jumpStaminaCost);
            OnPlayerJump.Invoke();
        }
    }

    /// <summary>
    /// Toggles blocking/aiming state.
    /// </summary>
    /// <param name="isHolding">True if the button is held, false otherwise.</param>
    public void BlockAim(bool isHolding)
    {
        if (isHolding && !isBlocking)
        {
            isBlocking = true;
            OnPlayerBlockStart.Invoke();
        }
        else if (!isHolding && isBlocking)
        {
            isBlocking = false;
            OnPlayerBlockEnd.Invoke();
        }
    }

    /// <summary>
    /// Retrieves the player's current camera transform.
    /// </summary>
    /// <returns>The transform of the player's camera.</returns>
    public Transform GetPlayerCameraTransform()
    {
        return cameraHolder;
    }
}