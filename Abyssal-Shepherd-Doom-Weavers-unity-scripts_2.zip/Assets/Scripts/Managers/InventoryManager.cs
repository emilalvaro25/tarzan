using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;
using System;

// This class will likely be defined elsewhere, but included here for completeness
// to satisfy the InventoryItemData dependency.
[System.Serializable]
public class StatEffect
{
    public PlayerStatType StatType;
    public float Amount;
}

public enum PlayerStatType
{
    Health,
    Stamina,
    Hunger,
    Thirst,
    Sanity
}

[CreateAssetMenu(fileName = "NewInventoryItem", menuName = "Inventory/Item")]
public class InventoryItemData : ScriptableObject
{
    public string ItemID = Guid.NewGuid().ToString(); // Unique ID for persistence
    public string ItemName = "New Item";
    [TextArea(3, 5)]
    public string ItemDescription = "A new item.";
    public Sprite ItemIcon;
    public bool IsStackable = true;
    public int MaxStackSize = 99;
    public bool CanBeUsed = false;
    public List<StatEffect> UseEffects; // Effects applied when item is used (e.g., healing, hunger reduction)
    public bool IsConsumable = false; // Does the item disappear after use?

    public virtual void Use(PlayerStats playerStats)
    {
        if (CanBeUsed && playerStats != null)
        {
            foreach (var effect in UseEffects)
            {
                switch (effect.StatType)
                {
                    case PlayerStatType.Health:
                        playerStats.AdjustHealth(effect.Amount);
                        break;
                    case PlayerStatType.Stamina:
                        playerStats.AdjustStamina(effect.Amount);
                        break;
                    case PlayerStatType.Hunger:
                        playerStats.AdjustHunger(effect.Amount);
                        break;
                    case PlayerStatType.Thirst:
                        playerStats.AdjustThirst(effect.Amount);
                        break;
                    case PlayerStatType.Sanity:
                        playerStats.AdjustSanity(effect.Amount);
                        break;
                }
            }
        }
    }
}

// Represents a single slot in the inventory, useful for fixed-size inventories or complex slot logic
[System.Serializable]
public class InventorySlot
{
    public InventoryItemData ItemData;
    public int Quantity;

    public InventorySlot(InventoryItemData itemData, int quantity)
    {
        ItemData = itemData;
        Quantity = quantity;
    }

    public void AddQuantity(int amount)
    {
        Quantity += amount;
    }

    public void RemoveQuantity(int amount)
    {
        Quantity -= amount;
    }

    public bool IsEmpty()
    {
        return ItemData == null || Quantity <= 0;
    }
}


public class InventoryManager : MonoBehaviour
{
    [Tooltip("The actual inventory storage. Using Dictionary<InventoryItemData, int> for flexibility with stacking.")]
    private Dictionary<InventoryItemData, int> _inventory = new Dictionary<InventoryItemData, int>();

    [Tooltip("List of blueprints the player currently possesses.")]
    private List<CraftingBlueprint> _blueprints = new List<CraftingBlueprint>();

    // Events for UI updates and other systems to react to inventory changes
    public static event UnityAction<Dictionary<InventoryItemData, int>> OnInventoryUpdated;
    public static event UnityAction<InventoryItemData, int> OnItemAdded;
    public static event UnityAction<InventoryItemData, int> OnItemRemoved;
    public static event UnityAction<CraftingBlueprint> OnBlueprintAdded;

    private PlayerStats _playerStats;
    private UIManager _uiManager;
    private SaveLoadManager _saveLoadManager; // Needed for persistence

    private void Awake()
    {
        _playerStats = FindObjectOfType<PlayerStats>();
        if (_playerStats == null)
        {
            Debug.LogError("InventoryManager: PlayerStats not found in scene. Inventory item usage may not function correctly.");
        }

        _uiManager = FindObjectOfType<UIManager>();
        if (_uiManager == null)
        {
            Debug.LogWarning("InventoryManager: UIManager not found in scene. Inventory UI may not update.");
        }

        _saveLoadManager = FindObjectOfType<SaveLoadManager>();
        if (_saveLoadManager == null)
        {
            Debug.LogError("InventoryManager: SaveLoadManager not found in scene. Inventory data will not persist!");
        }
    }

    private void OnEnable()
    {
        // Subscribe to SaveLoadManager's events to load inventory
        if (_saveLoadManager != null)
        {
            _saveLoadManager.OnLoadGameData += LoadInventoryState;
            _saveLoadManager.OnSaveGameDataRequest += GetInventorySaveData;
        }
    }

    private void OnDisable()
    {
        // Unsubscribe to prevent memory leaks
        if (_saveLoadManager != null)
        {
            _saveLoadManager.OnLoadGameData -= LoadInventoryState;
            _saveLoadManager.OnSaveGameDataRequest -= GetInventorySaveData;
        }
    }

    /// <summary>
    /// Adds an item to the inventory. Handles stacking if the item is stackable.
    /// </summary>
    /// <param name="itemData">ScriptableObject representing the item type.</param>
    /// <param name="quantity">The amount of the item to add.</param>
    public void AddItem(InventoryItemData itemData, int quantity)
    {
        if (itemData == null)
        {
            Debug.LogWarning("Attempted to add a null item to inventory.");
            return;
        }
        if (quantity <= 0)
        {
            Debug.LogWarning($"Attempted to add a non-positive quantity ({quantity}) of item {itemData.ItemName}.");
            return;
        }

        if (_inventory.ContainsKey(itemData))
        {
            int currentQuantity = _inventory[itemData];
            if (itemData.IsStackable)
            {
                int remainingSpace = itemData.MaxStackSize - currentQuantity;
                int amountToAdd = Mathf.Min(quantity, remainingSpace);
                _inventory[itemData] += amountToAdd;
                if (amountToAdd < quantity)
                {
                    Debug.LogWarning($"Inventory full for {itemData.ItemName}. Added {amountToAdd}, {quantity - amountToAdd} left behind.");
                    // Potentially spawn remaining as a world item or notify player
                }
            }
            else
            {
                // If not stackable and already exists, we can't add more of this specific instance.
                // For production, if "IsStackable" is false, we should ensure unique instances are handled,
                // or simply prevent adding more if one already exists for unstackable items like unique quest items.
                // For simplicity, this assumes non-stackable items are unique entries, or for now, prevents adding more.
                Debug.LogWarning($"Cannot add more of non-stackable item {itemData.ItemName}. Already exists in inventory.");
                return; // Or create a new entry for truly unique instances if InventoryItemData was a class
            }
        }
        else
        {
            _inventory.Add(itemData, quantity);
        }

        Debug.Log($"Added {quantity} x {itemData.ItemName}. Current: {_inventory[itemData]}");
        OnItemAdded?.Invoke(itemData, quantity);
        OnInventoryUpdated?.Invoke(_inventory); // Notify UI
    }

    /// <summary>
    /// Removes an item from the inventory.
    /// </summary>
    /// <param name="itemData">ScriptableObject representing the item type to remove.</param>
    /// <param name="quantity">The amount of the item to remove.</param>
    public void RemoveItem(InventoryItemData itemData, int quantity)
    {
        if (itemData == null)
        {
            Debug.LogWarning("Attempted to remove a null item from inventory.");
            return;
        }
        if (quantity <= 0)
        {
            Debug.LogWarning($"Attempted to remove a non-positive quantity ({quantity}) of item {itemData.ItemName}.");
            return;
        }

        if (_inventory.ContainsKey(itemData))
        {
            int currentQuantity = _inventory[itemData];
            int amountToRemove = Mathf.Min(quantity, currentQuantity);
            _inventory[itemData] -= amountToRemove;

            if (_inventory[itemData] <= 0)
            {
                _inventory.Remove(itemData);
                Debug.Log($"Removed all {itemData.ItemName}.");
            }
            else
            {
                Debug.Log($"Removed {amountToRemove} x {itemData.ItemName}. Remaining: {_inventory[itemData]}");
            }

            OnItemRemoved?.Invoke(itemData, amountToRemove);
            OnInventoryUpdated?.Invoke(_inventory); // Notify UI
        }
        else
        {
            Debug.LogWarning($"Attempted to remove {itemData.ItemName} which is not in inventory.");
        }
    }

    /// <summary>
    /// Attempts to use an item from the inventory. Handles consumable logic.
    /// </summary>
    /// <param name="itemData">The item to use.</param>
    public void UseItem(InventoryItemData itemData)
    {
        if (itemData == null)
        {
            Debug.LogWarning("Attempted to use a null item.");
            return;
        }
        if (!_inventory.ContainsKey(itemData) || _inventory[itemData] <= 0)
        {
            Debug.LogWarning($"Cannot use {itemData.ItemName}: Not in inventory or quantity is zero.");
            _uiManager?.ShowMessage($"You don't have any {itemData.ItemName}!");
            return;
        }
        if (!itemData.CanBeUsed)
        {
            Debug.LogWarning($"Item {itemData.ItemName} cannot be used.");
            _uiManager?.ShowMessage($"{itemData.ItemName} cannot be used directly.");
            return;
        }

        // Apply item effects
        itemData.Use(_playerStats);
        _uiManager?.ShowMessage($"Used {itemData.ItemName}.");

        // Remove if consumable
        if (itemData.IsConsumable)
        {
            RemoveItem(itemData, 1);
        }
        else
        {
            // Even if not consumable, notify UI that "use" happened if needed, might change icon/state etc.
            OnInventoryUpdated?.Invoke(_inventory);
        }
    }

    /// <summary>
    /// Checks if the inventory contains a specific item with at least the given quantity.
    /// </summary>
    /// <param name="itemData">The item to check for.</param>
    /// <param name="quantity">The minimum quantity required.</param>
    /// <returns>True if the item is present in the required quantity, false otherwise.</returns>
    public bool HasItem(InventoryItemData itemData, int quantity)
    {
        if (itemData == null || quantity <= 0) return false;
        return _inventory.ContainsKey(itemData) && _inventory[itemData] >= quantity;
    }

    /// <summary>
    /// Adds a crafting blueprint to the player's known blueprints.
    /// </summary>
    /// <param name="blueprint">The blueprint to add.</param>
    public void AddBlueprint(CraftingBlueprint blueprint)
    {
        if (blueprint == null)
        {
            Debug.LogWarning("Attempted to add a null blueprint.");
            return;
        }
        if (!_blueprints.Contains(blueprint))
        {
            _blueprints.Add(blueprint);
            Debug.Log($"Learned new blueprint: {blueprint.name}");
            OnBlueprintAdded?.Invoke(blueprint);
            _uiManager?.ShowMessage($"Learned new recipe: {blueprint.ResultItem.ItemName}!");
        }
        else
        {
            Debug.Log($"Blueprint for {blueprint.name} already known.");
        }
    }

    /// <summary>
    /// Checks if the player knows a specific crafting blueprint.
    /// </summary>
    /// <param name="blueprint">The blueprint to check for.</param>
    /// <returns>True if the blueprint is known, false otherwise.</returns>
    public bool HasBlueprint(CraftingBlueprint blueprint)
    {
        if (blueprint == null) return false;
        return _blueprints.Contains(blueprint);
    }

    /// <summary>
    /// Retrieves all currently known crafting blueprints.
    /// </summary>
    /// <returns>A list of known blueprints.</returns>
    public List<CraftingBlueprint> GetAllBlueprints()
    {
        return new List<CraftingBlueprint>(_blueprints); // Return a copy to prevent external modification
    }

    /// <summary>
    /// Retrieves all items currently in the inventory along with their quantities.
    /// </summary>
    /// <returns>A dictionary of item data and their quantities.</returns>
    public Dictionary<InventoryItemData, int> GetAllItems()
    {
        return new Dictionary<InventoryItemData, int>(_inventory); // Return a copy
    }

    /// <summary>
    /// Retrieves the InventoryItemData ScriptableObject by its unique ItemID.
    /// This method is crucial for re-populating inventory from save data,
    /// as direct ScriptableObject references cannot be serialized easily.
    /// This assumes a way to look up ScriptableObjects by ID (e.g., a central ItemDatabase).
    /// For this implementation, we'll simulate a lookup.
    /// </summary>
    /// <param name="itemID">The unique ID of the item.</param>
    /// <returns>The InventoryItemData ScriptableObject if found, otherwise null.</returns>
    public InventoryItemData GetItemData(string itemID)
    {
        // In a real game, this would likely query a central Asset Database or a pre-loaded dictionary
        // of all possible InventoryItemData ScriptableObjects.
        // For demonstration, we'll iterate through existing inventory items to find a match.
        // This is NOT performant for large numbers of items and should be replaced by a proper asset management system.

        foreach (var item in _inventory.Keys)
        {
            if (item.ItemID == itemID)
            {
                return item;
            }
        }

        // Fallback: If not in current inventory, try to find it among all known blueprints' result items
        foreach (var blueprint in _blueprints)
        {
            if (blueprint.ResultItem != null && blueprint.ResultItem.ItemID == itemID)
            {
                return blueprint.ResultItem;
            }
            // Also check required items if they are complex ScriptableObjects themselves
            foreach(var requiredItem in blueprint.RequiredItems.Keys)
            {
                if (requiredItem.ItemID == itemID) return requiredItem;
            }
        }


        Debug.LogWarning($"InventoryManager: Could not find InventoryItemData for ItemID: {itemID}. " +
                         "Ensure all ScriptableObject item definitions are accessible/loaded.");

        return null;
    }


    // --- Save/Load Integration ---

    // Serializable class to hold inventory data for persistence
    [System.Serializable]
    public class InventorySaveData
    {
        public List<ItemEntry> items = new List<ItemEntry>();
        public List<string> learnedBlueprints = new List<string>(); // Store blueprint IDs

        [System.Serializable]
        public class ItemEntry
        {
            public string itemID;
            public int quantity;

            public ItemEntry(string id, int qty)
            {
                itemID = id;
                quantity = qty;
            }
        }
    }

    /// <summary>
    /// Provides the current inventory and blueprint state for saving.
    /// Called by SaveLoadManager.
    /// </summary>
    /// <returns>An object containing all relevant inventory data.</returns>
    public object GetInventorySaveData()
    {
        InventorySaveData saveData = new InventorySaveData();

        foreach (var itemEntry in _inventory)
        {
            saveData.items.Add(new InventorySaveData.ItemEntry(itemEntry.Key.ItemID, itemEntry.Value));
        }

        foreach (var blueprint in _blueprints)
        {
            saveData.learnedBlueprints.Add(blueprint.BlueprintID);
        }

        return saveData;
    }

    /// <summary>
    /// Loads the inventory and blueprint state from saved data.
    /// Called by SaveLoadManager.
    /// </summary>
    /// <param name="data">The inventory save data object.</param>
    public void LoadInventoryState(object data)
    {
        if (data is InventorySaveData saveData)
        {
            _inventory.Clear();
            _blueprints.Clear();

            foreach (var itemEntry in saveData.items)
            {
                InventoryItemData itemData = GetItemData(itemEntry.itemID); // Look up ScriptableObject by ID
                if (itemData != null)
                {
                    _inventory.Add(itemData, itemEntry.quantity);
                }
                else
                {
                    Debug.LogWarning($"InventoryManager: Failed to load item with ID {itemEntry.itemID}. Item definition not found.");
                }
            }

            // Load blueprints (requires a way to get blueprint SO from ID)
            foreach (var blueprintID in saveData.learnedBlueprints)
            {
                CraftingBlueprint blueprint = GetBlueprintData(blueprintID); // Assume a similar lookup for blueprints
                if (blueprint != null)
                {
                    _blueprints.Add(blueprint);
                }
                else
                {
                    Debug.LogWarning($"InventoryManager: Failed to load blueprint with ID {blueprintID}. Blueprint definition not found.");
                }
            }

            Debug.Log("Inventory and blueprints loaded successfully.");
            OnInventoryUpdated?.Invoke(_inventory); // Update UI after loading
        }
        else if (data != null)
        {
            Debug.LogError($"InventoryManager: Invalid data type for loading inventory state. Expected InventorySaveData, got {data.GetType().Name}.");
        }
        else
        {
            Debug.Log("InventoryManager: No inventory save data provided, initializing empty inventory.");
            _inventory.Clear();
            _blueprints.Clear();
            OnInventoryUpdated?.Invoke(_inventory);
        }
    }

    /// <summary>
    /// Helper to retrieve CraftingBlueprint ScriptableObject by its unique BlueprintID.
    /// Similar to GetItemData, this needs a proper asset lookup system.
    /// </summary>
    /// <param name="blueprintID">The unique ID of the blueprint.</param>
    /// <returns>The CraftingBlueprint ScriptableObject if found, otherwise null.</returns>
    private CraftingBlueprint GetBlueprintData(string blueprintID)
    {
        // This is a placeholder. In a real system, you'd have a central registry
        // of all CraftingBlueprint ScriptableObjects.
        // For now, let's assume all possible blueprints are known by CraftingManager
        // and it can provide a lookup.
        CraftingManager craftingManager = FindObjectOfType<CraftingManager>();
        if (craftingManager != null)
        {
            return craftingManager.GetBlueprintByID(blueprintID); // Assuming CraftingManager has this method
        }
        Debug.LogWarning($"InventoryManager: No CraftingManager found to look up blueprint ID: {blueprintID}");
        return null;
    }
}