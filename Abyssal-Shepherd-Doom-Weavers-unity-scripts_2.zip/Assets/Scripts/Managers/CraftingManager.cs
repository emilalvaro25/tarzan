using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;
using System;

// Represents the type of workbench, influencing available recipes.
public enum WorkbenchType
{
    None, // For crafting anywhere or for blueprints not requiring a specific workbench
    Bamboo,
    Stone,
    Iron
}

/// <summary>
/// A ScriptableObject representing a crafting recipe.
/// Contains the required items and the resulting item.
/// </summary>
[CreateAssetMenu(fileName = "NewCraftingBlueprint", menuName = "Crafting/Blueprint")]
public class CraftingBlueprint : ScriptableObject
{
    public string BlueprintID = Guid.NewGuid().ToString(); // Unique ID for persistence
    public InventoryItemData ResultItem; // The item produced by this blueprint
    public int ResultQuantity = 1; // Quantity of the result item

    // Using a List of a custom struct to handle required items and quantities,
    // as Dictionary<ScriptableObject, int> does not serialize directly in Unity editor.
    public List<CraftingRequirement> RequiredItemsList;

    public WorkbenchType RequiredWorkbench; // Type of workbench needed for this recipe

    [System.Serializable]
    public struct CraftingRequirement
    {
        public InventoryItemData ItemData;
        public int Quantity;
    }

    // Helper to convert List to Dictionary for easier lookup in code
    private Dictionary<InventoryItemData, int> _requiredItemsDictionary;
    public Dictionary<InventoryItemData, int> RequiredItems
    {
        get
        {
            if (_requiredItemsDictionary == null || _requiredItemsDictionary.Count != RequiredItemsList.Count)
            {
                _requiredItemsDictionary = new Dictionary<InventoryItemData, int>();
                foreach (var req in RequiredItemsList)
                {
                    if (req.ItemData != null)
                    {
                        _requiredItemsDictionary[req.ItemData] = req.Quantity;
                    }
                }
            }
            return _requiredItemsDictionary;
        }
    }
}

/// <summary>
/// Manages the crafting system, allowing players to create items using blueprints and collected resources.
/// Handles crafting logic and workbench interactions.
/// </summary>
public class CraftingManager : MonoBehaviour
{
    [Tooltip("All possible crafting blueprints available in the game.")]
    [SerializeField] private List<CraftingBlueprint> _allGameBlueprints;

    private InventoryManager _inventoryManager;
    private UIManager _uiManager;
    private WorkbenchType _currentWorkbench = WorkbenchType.None;

    // A dictionary for quick lookup of blueprints by their ID for save/load system.
    private Dictionary<string, CraftingBlueprint> _blueprintLookup;

    private void Awake()
    {
        _inventoryManager = FindObjectOfType<InventoryManager>();
        if (_inventoryManager == null)
        {
            Debug.LogError("CraftingManager: InventoryManager not found in scene. Crafting will not function!");
        }

        _uiManager = FindObjectOfType<UIManager>();
        if (_uiManager == null)
        {
            Debug.LogError("CraftingManager: UIManager not found in scene. Crafting UI will not update!");
        }

        InitializeBlueprintLookup();
    }

    /// <summary>
    /// Initializes the _blueprintLookup dictionary for efficient ID-based retrieval.
    /// This should be called once, for example, in Awake.
    /// </summary>
    private void InitializeBlueprintLookup()
    {
        _blueprintLookup = new Dictionary<string, CraftingBlueprint>();
        foreach (var blueprint in _allGameBlueprints)
        {
            if (!_blueprintLookup.ContainsKey(blueprint.BlueprintID))
            {
                _blueprintLookup.Add(blueprint.BlueprintID, blueprint);
            }
            else
            {
                Debug.LogWarning($"CraftingManager: Duplicate BlueprintID found for {blueprint.name} ({blueprint.BlueprintID}). Ensure all blueprints have unique IDs.");
            }
        }
    }

    /// <summary>
    /// Attempts to craft an item using the given blueprint.
    /// Checks if the player has the required resources and workbench.
    /// </summary>
    /// <param name="blueprint">The blueprint to use for crafting.</param>
    public void CraftItem(CraftingBlueprint blueprint)
    {
        if (blueprint == null)
        {
            Debug.LogError("CraftingManager: Attempted to craft with a null blueprint.");
            _uiManager?.ShowMessage("Crafting failed: Invalid recipe.");
            return;
        }

        if (_inventoryManager == null)
        {
            Debug.LogError("CraftingManager: InventoryManager is null, cannot craft.");
            _uiManager?.ShowMessage("Crafting failed: Inventory system not available.");
            return;
        }

        if (!CanCraft(blueprint))
        {
            Debug.LogWarning($"CraftingManager: Cannot craft {blueprint.ResultItem.ItemName}. Missing requirements.");
            _uiManager?.ShowMessage($"Cannot craft {blueprint.ResultItem.ItemName}: Missing items or wrong workbench.");
            return;
        }

        // Remove required items from inventory
        foreach (var requirement in blueprint.RequiredItems)
        {
            _inventoryManager.RemoveItem(requirement.Key, requirement.Value);
        }

        // Add the result item to inventory
        _inventoryManager.AddItem(blueprint.ResultItem, blueprint.ResultQuantity);

        Debug.Log($"Crafted {blueprint.ResultQuantity} x {blueprint.ResultItem.ItemName} using blueprint: {blueprint.name}");
        _uiManager?.ShowMessage($"Successfully crafted {blueprint.ResultQuantity} x {blueprint.ResultItem.ItemName}!");

        // After crafting, update UI to reflect new inventory and potentially updated craftable status
        _uiManager?.UpdateInventoryUI(_inventoryManager.GetAllItems());
        _uiManager?.UpdateCraftingUI(GetAvailableBlueprints(_currentWorkbench));
    }

    /// <summary>
    /// Checks if the player can craft an item according to the given blueprint.
    /// This includes checking required items and the active workbench.
    /// </summary>
    /// <param name="blueprint">The blueprint to check.</param>
    /// <returns>True if the item can be crafted, false otherwise.</returns>
    public bool CanCraft(CraftingBlueprint blueprint)
    {
        if (blueprint == null || _inventoryManager == null)
        {
            return false;
        }

        // Check workbench requirement
        if (blueprint.RequiredWorkbench != WorkbenchType.None && blueprint.RequiredWorkbench != _currentWorkbench)
        {
            return false;
        }

        // Check if player has the blueprint learned (this logic assumes blueprints are "learned" by InventoryManager)
        if (!_inventoryManager.HasBlueprint(blueprint))
        {
            return false;
        }

        // Check required items
        foreach (var requirement in blueprint.RequiredItems)
        {
            if (!_inventoryManager.HasItem(requirement.Key, requirement.Value))
            {
                return false; // Player doesn't have enough of a required item
            }
        }

        // All checks passed
        return true;
    }

    /// <summary>
    /// Retrieves a list of all crafting blueprints currently available to the player
    /// based on learned blueprints and the currently active workbench.
    /// </summary>
    /// <param name="workbenchType">The type of workbench currently being used. Use WorkbenchType.None for general crafting.</param>
    /// <returns>A list of available crafting blueprints.</returns>
    public List<CraftingBlueprint> GetAvailableBlueprints(WorkbenchType workbenchType)
    {
        List<CraftingBlueprint> availableBlueprints = new List<CraftingBlueprint>();
        if (_inventoryManager == null)
        {
            return availableBlueprints;
        }

        List<CraftingBlueprint> learnedBlueprints = _inventoryManager.GetAllBlueprints();

        foreach (CraftingBlueprint blueprint in learnedBlueprints)
        {
            // If the blueprint requires a specific workbench, check if it matches the current one.
            // If the blueprint requires no specific workbench (None) or the current workbench is None, it's considered generally available.
            bool workbenchMatches = (blueprint.RequiredWorkbench == WorkbenchType.None || blueprint.RequiredWorkbench == workbenchType);
            
            if (workbenchMatches)
            {
                availableBlueprints.Add(blueprint);
            }
        }
        return availableBlueprints;
    }

    /// <summary>
    /// Sets the type of workbench the player is currently interacting with.
    /// This influences which recipes are available.
    /// </summary>
    /// <param name="type">The type of the workbench.</param>
    public void SetCurrentWorkbench(WorkbenchType type)
    {
        _currentWorkbench = type;
        Debug.Log($"Current workbench set to: {_currentWorkbench}");
        // Optionally, inform UIManager to update crafting UI immediately
        _uiManager?.UpdateCraftingUI(GetAvailableBlueprints(_currentWorkbench));
    }

    /// <summary>
    /// Retrieves a CraftingBlueprint ScriptableObject by its unique BlueprintID.
    /// This is primarily used by the InventoryManager for loading saved blueprint data.
    /// </summary>
    /// <param name="blueprintID">The unique ID of the blueprint.</param>
    /// <returns>The CraftingBlueprint ScriptableObject if found, otherwise null.</returns>
    public CraftingBlueprint GetBlueprintByID(string blueprintID)
    {
        if (_blueprintLookup == null || _blueprintLookup.Count == 0)
        {
            InitializeBlueprintLookup(); // Ensure lookup is initialized
        }

        if (_blueprintLookup.TryGetValue(blueprintID, out CraftingBlueprint blueprint))
        {
            return blueprint;
        }
        
        Debug.LogWarning($"CraftingManager: Blueprint with ID '{blueprintID}' not found in known blueprints.");
        return null;
    }
}