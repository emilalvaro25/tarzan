using UnityEngine;
using System;
using System.Collections.Generic;

public enum PlayerStatType
{
    Health,
    Stamina,
    Hunger,
    Thirst,
    Sanity
}

public class PlayerStats : MonoBehaviour
{
    // Events for UI updates and other systems
    public static event Action<PlayerStatType, float> OnStatChanged;
    public static event Action OnPlayerDeath;
    public static event Action<bool> OnSanityLowStatusChanged; // To notify PostProcessEffectController

    [Header("Current Stats")]
    [SerializeField, Range(0, 100)]
    private float _health = 100f;
    public float Health => _health;

    [SerializeField, Range(0, 100)]
    private float _stamina = 100f;
    public float Stamina => _stamina;

    [SerializeField, Range(0, 100)]
    private float _hunger = 100f;
    public float Hunger => _hunger;

    [SerializeField, Range(0, 100)]
    private float _thirst = 100f;
    public float Thirst => _thirst;

    [SerializeField, Range(0, 100)]
    private float _sanity = 100f;
    public float Sanity => _sanity;

    [Header("Stat Decay Rates (Units per second)")]
    [SerializeField]
    private float hungerDecayRate = 0.5f; // Hunger decreases by 0.5 units per second
    [SerializeField]
    private float thirstDecayRate = 0.7f; // Thirst decreases by 0.7 units per second
    [SerializeField]
    private float sanityDecayRate = 0.2f; // Sanity decreases by 0.2 units per second

    [Header("Thresholds")]
    [SerializeField, Range(0, 100)]
    private float lowSanityThreshold = 25f;

    private bool _isSanityLowActive = false;

    private void Awake()
    {
        // Initialize stats to max
        _health = 100f;
        _stamina = 100f;
        _hunger = 100f;
        _thirst = 100f;
        _sanity = 100f;

        // Immediately update UI with initial values
        UpdateUI(PlayerStatType.Health, _health);
        UpdateUI(PlayerStatType.Stamina, _stamina);
        UpdateUI(PlayerStatType.Hunger, _hunger);
        UpdateUI(PlayerStatType.Thirst, _thirst);
        UpdateUI(PlayerStatType.Sanity, _sanity);
    }

    void Update()
    {
        // Apply continuous stat decay
        AdjustHunger(-hungerDecayRate * Time.deltaTime);
        AdjustThirst(-thirstDecayRate * Time.deltaTime);
        AdjustSanity(-sanityDecayRate * Time.deltaTime);

        // Check for low sanity status change
        bool currentSanityLow = IsSanityLow();
        if (currentSanityLow != _isSanityLowActive)
        {
            _isSanityLowActive = currentSanityLow;
            OnSanityLowStatusChanged?.Invoke(_isSanityLowActive);
        }

        // Check for death
        if (IsDead())
        {
            OnPlayerDeath?.Invoke();
            // Optionally, disable further updates or trigger game over sequence
            enabled = false; 
        }
    }

    /// <summary>
    /// Adjusts the player's health by a given amount.
    /// </summary>
    /// <param name="amount">The amount to adjust health by. Positive for healing, negative for damage.</param>
    public void AdjustHealth(float amount)
    {
        float previousHealth = _health;
        _health = Mathf.Clamp(_health + amount, 0f, 100f);
        if (_health != previousHealth)
        {
            UpdateUI(PlayerStatType.Health, _health);
        }
    }

    /// <summary>
    /// Adjusts the player's stamina by a given amount.
    /// </summary>
    /// <param name="amount">The amount to adjust stamina by. Positive for recovery, negative for usage.</param>
    public void AdjustStamina(float amount)
    {
        float previousStamina = _stamina;
        _stamina = Mathf.Clamp(_stamina + amount, 0f, 100f);
        if (_stamina != previousStamina)
        {
            UpdateUI(PlayerStatType.Stamina, _stamina);
        }
    }

    /// <summary>
    /// Adjusts the player's hunger by a given amount.
    /// </summary>
    /// <param name="amount">The amount to adjust hunger by. Positive for satiation, negative for increasing hunger.</param>
    public void AdjustHunger(float amount)
    {
        float previousHunger = _hunger;
        _hunger = Mathf.Clamp(_hunger + amount, 0f, 100f);
        if (_hunger != previousHunger)
        {
            UpdateUI(PlayerStatType.Hunger, _hunger);
        }
    }

    /// <summary>
    /// Adjusts the player's thirst by a given amount.
    /// </summary>
    /// <param name="amount">The amount to adjust thirst by. Positive for hydration, negative for increasing thirst.</param>
    public void AdjustThirst(float amount)
    {
        float previousThirst = _thirst;
        _thirst = Mathf.Clamp(_thirst + amount, 0f, 100f);
        if (_thirst != previousThirst)
        {
            UpdateUI(PlayerStatType.Thirst, _thirst);
        }
    }

    /// <summary>
    /// Adjusts the player's sanity by a given amount.
    /// </summary>
    /// <param name="amount">The amount to adjust sanity by. Positive for recovery, negative for decreasing sanity.</param>
    public void AdjustSanity(float amount)
    {
        float previousSanity = _sanity;
        _sanity = Mathf.Clamp(_sanity + amount, 0f, 100f);
        if (_sanity != previousSanity)
        {
            UpdateUI(PlayerStatType.Sanity, _sanity);
        }
    }

    /// <summary>
    /// Gets the current value of a specified player stat.
    /// </summary>
    /// <param name="statType">The type of stat to retrieve.</param>
    /// <returns>The current value of the specified stat.</returns>
    public float GetStat(PlayerStatType statType)
    {
        return statType switch
        {
            PlayerStatType.Health => _health,
            PlayerStatType.Stamina => _stamina,
            PlayerStatType.Hunger => _hunger,
            PlayerStatType.Thirst => _thirst,
            PlayerStatType.Sanity => _sanity,
            _ => throw new ArgumentOutOfRangeException(nameof(statType), statType, "Invalid PlayerStatType")
        };
    }

    /// <summary>
    /// Checks if the player's health is at or below zero.
    /// </summary>
    /// <returns>True if the player is dead, false otherwise.</returns>
    public bool IsDead()
    {
        return _health <= 0f;
    }

    /// <summary>
    /// Checks if the player's sanity is below the low sanity threshold.
    /// </summary>
    /// <returns>True if sanity is low, false otherwise.</returns>
    public bool IsSanityLow()
    {
        return _sanity < lowSanityThreshold;
    }

    /// <summary>
    /// Helper method to invoke the OnStatChanged event.
    /// This centralizes UI update notifications.
    /// </summary>
    /// <param name="statType">The type of stat that changed.</param>
    /// <param name="value">The new value of the stat.</param>
    private void UpdateUI(PlayerStatType statType, float value)
    {
        OnStatChanged?.Invoke(statType, value);
    }

    // Method to apply stat changes from an Item
    public void ApplyItemEffect(ItemData itemData)
    {
        if (itemData == null || itemData.StatEffects == null) return;

        foreach (var effect in itemData.StatEffects)
        {
            switch (effect.StatType)
            {
                case PlayerStatType.Health:
                    AdjustHealth(effect.Amount);
                    break;
                case PlayerStatType.Stamina:
                    AdjustStamina(effect.Amount);
                    break;
                case PlayerStatType.Hunger:
                    AdjustHunger(effect.Amount);
                    break;
                case PlayerStatType.Thirst:
                    AdjustThirst(effect.Amount);
                    break;
                case PlayerStatType.Sanity:
                    AdjustSanity(effect.Amount);
                    break;
            }
        }
    }

    // Method to apply stat boosts from a Memory Fragment
    public void ApplyMemoryFragmentBoost(MemoryFragmentData fragmentData)
    {
        if (fragmentData == null || fragmentData.StatBoosts == null) return;

        foreach (var boost in fragmentData.StatBoosts)
        {
            switch (boost.StatType)
            {
                case PlayerStatType.Health:
                    AdjustHealth(boost.Amount);
                    break;
                case PlayerStatType.Stamina:
                    AdjustStamina(boost.Amount);
                    break;
                case PlayerStatType.Hunger:
                    AdjustHunger(boost.Amount);
                    break;
                case PlayerStatType.Thirst:
                    AdjustThirst(boost.Amount);
                    break;
                case PlayerStatType.Sanity:
                    AdjustSanity(boost.Amount);
                    break;
            }
        }
    }

    // Public method to set all stats for loading game state
    public void SetAllStats(float health, float stamina, float hunger, float thirst, float sanity)
    {
        _health = Mathf.Clamp(health, 0f, 100f);
        _stamina = Mathf.Clamp(stamina, 0f, 100f);
        _hunger = Mathf.Clamp(hunger, 0f, 100f);
        _thirst = Mathf.Clamp(thirst, 0f, 100f);
        _sanity = Mathf.Clamp(sanity, 0f, 100f);

        UpdateUI(PlayerStatType.Health, _health);
        UpdateUI(PlayerStatType.Stamina, _stamina);
        UpdateUI(PlayerStatType.Hunger, _hunger);
        UpdateUI(PlayerStatType.Thirst, _thirst);
        UpdateUI(PlayerStatType.Sanity, _sanity);

        // Ensure hallucination effect is updated on load
        bool currentSanityLow = IsSanityLow();
        if (currentSanityLow != _isSanityLowActive)
        {
            _isSanityLowActive = currentSanityLow;
            OnSanityLowStatusChanged?.Invoke(_isSanityLowActive);
        }
    }
}

// Dummy classes to satisfy dependencies. In a real project, these would be proper ScriptableObjects or data structures.
// These are included to ensure the PlayerStats script compiles and demonstrates intended interactions.

[Serializable]
public class StatEffect
{
    public PlayerStatType StatType;
    public float Amount;
}

[Serializable]
public class ItemData // Represents a base class or ScriptableObject for items
{
    public string ItemID;
    public string ItemName;
    public List<StatEffect> StatEffects; // Effects this item has on stats
}

[Serializable]
public class MemoryFragmentData // Represents a ScriptableObject for memory fragments
{
    public string FragmentID;
    public string FragmentName;
    public List<StatEffect> StatBoosts; // Stat boosts this fragment provides
}