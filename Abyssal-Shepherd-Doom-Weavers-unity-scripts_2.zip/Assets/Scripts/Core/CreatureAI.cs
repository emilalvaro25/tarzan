using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;
using System; // For ArgumentOutOfRangeException

public enum CreatureState
{
    Idle,
    Patrolling,
    Chasing,
    Attacking,
    Fleeing,
    Dead // Special state for dead creatures
}

public class CreatureAI : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private PlayerController playerController;
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private WorldManager worldManager;
    [SerializeField] private QuestManager questManager;
    [SerializeField] private AudioManager audioManager;
    [SerializeField] private ObjectPoolManager objectPoolManager; // For spawning/despawning visual effects or creature instances

    [Header("Creature Attributes")]
    [SerializeField] private float health = 100f;
    [SerializeField] private float detectionRange = 20f;
    [SerializeField] private float attackRange = 2f;
    [SerializeField] private float movementSpeed = 3f;
    [SerializeField] private float patrolSpeed = 1.5f;
    [SerializeField] private float chaseSpeed = 5f;
    [SerializeField] private float attackDamage = 10f;
    [SerializeField] private float attackCooldown = 2f;
    [SerializeField] private float patrolRadius = 10f; // Radius for random patrol points
    [SerializeField] private float fleeHealthThreshold = 20f; // Health below which creature flees
    [SerializeField] private LayerMask playerLayer; // Layer where the player is
    [SerializeField] private LayerMask obstacleLayer; // Layers that block line of sight

    [Header("Audio Clips")]
    [SerializeField] private AudioClip attackSound;
    [SerializeField] private AudioClip takeDamageSound;
    [SerializeField] private AudioClip deathSound;
    [SerializeField] private AudioClip idleSound; // Optional ambient sound
    [SerializeField] private float idleSoundInterval = 10f;

    [Header("Quest Integration")]
    [Tooltip("Optional Quest ID to progress upon this creature's death.")]
    [SerializeField] private string questObjectiveOnDeathID;

    // Internal State
    private CreatureState currentState = CreatureState.Idle;
    private NavMeshAgent navMeshAgent;
    private Transform currentTarget;
    private float lastAttackTime = -Mathf.Infinity;
    private Vector3 patrolDestination;
    private bool isDead = false;
    private float currentIdleSoundTimer;

    private const float NAVMESH_SAMPLE_RADIUS = 10f; // For sampling points on NavMesh
    private const float NAVMESH_PATH_THRESHOLD = 0.5f; // How close to a destination before re-calculating or moving to next

    private void Awake()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();
        if (navMeshAgent == null)
        {
            Debug.LogError($"CreatureAI: {gameObject.name} requires a NavMeshAgent component.", this);
            enabled = false;
            return;
        }

        if (playerController == null) Debug.LogError("CreatureAI: PlayerController not assigned.", this);
        if (playerStats == null) Debug.LogError("CreatureAI: PlayerStats not assigned.", this);
        if (worldManager == null) Debug.LogError("CreatureAI: WorldManager not assigned.", this);
        if (questManager == null) Debug.LogError("CreatureAI: QuestManager not assigned.", this);
        if (audioManager == null) Debug.LogError("CreatureAI: AudioManager not assigned.", this);
        if (objectPoolManager == null) Debug.LogError("CreatureAI: ObjectPoolManager not assigned.", this);

        navMeshAgent.speed = movementSpeed;
        currentIdleSoundTimer = idleSoundInterval; // Initialize timer for idle sounds
    }

    private void Start()
    {
        // Ensure starting state is handled correctly
        ChangeState(CreatureState.Idle);
    }

    /// <summary>
    /// Called every frame by Unity. Updates the creature's AI based on its current state.
    /// </summary>
    public void Update()
    {
        if (isDead) return;

        currentIdleSoundTimer -= Time.deltaTime;
        if (currentIdleSoundTimer <= 0f && currentState == CreatureState.Idle)
        {
            audioManager?.PlaySFX(idleSound, transform.position, 0.5f); // Play idle sound quietly
            currentIdleSoundTimer = idleSoundInterval;
        }

        switch (currentState)
        {
            case CreatureState.Idle:
                HandleIdleState();
                break;
            case CreatureState.Patrolling:
                HandlePatrollingState();
                break;
            case CreatureState.Chasing:
                HandleChasingState();
                break;
            case CreatureState.Attacking:
                HandleAttackingState();
                break;
            case CreatureState.Fleeing:
                HandleFleeingState();
                break;
            case CreatureState.Dead:
                // No update needed for dead state, unless handling death animation/despawn
                break;
            default:
                Debug.LogWarning($"CreatureAI: Unknown state {currentState} on {gameObject.name}");
                break;
        }
    }

    /// <summary>
    /// Draws gizmos in the editor for debugging purposes (e.g., detection range, attack range).
    /// </summary>
    public void OnDrawGizmosSelected()
    {
        // Detection Range
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRange);

        // Attack Range
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRange);

        // Patrol destination
        if (currentState == CreatureState.Patrolling)
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawWireSphere(patrolDestination, 0.5f);
            Gizmos.DrawLine(transform.position, patrolDestination);
        }

        // Current target path
        if (navMeshAgent != null && navMeshAgent.hasPath)
        {
            Gizmos.color = Color.green;
            Vector3[] pathCorners = navMeshAgent.path.corners;
            for (int i = 0; i < pathCorners.Length - 1; i++)
            {
                Gizmos.DrawLine(pathCorners[i], pathCorners[i + 1]);
            }
        }
    }

    /// <summary>
    /// Sets the target for the creature's AI. This is typically the player.
    /// </summary>
    /// <param name="target">The Transform of the target.</param>
    public void SetTarget(Transform target)
    {
        currentTarget = target;
        if (!isDead && currentTarget != null)
        {
            ChangeState(CreatureState.Chasing);
        }
    }

    /// <summary>
    /// Applies damage to the creature.
    /// </summary>
    /// <param name="amount">The amount of damage to inflict.</param>
    public void TakeDamage(float amount)
    {
        if (isDead) return;

        health -= amount;
        audioManager?.PlaySFX(takeDamageSound, transform.position);
        Debug.Log($"{gameObject.name} took {amount} damage. Health: {health}");

        if (health <= 0)
        {
            Die();
        }
        else if (health <= fleeHealthThreshold && currentState != CreatureState.Fleeing)
        {
            ChangeState(CreatureState.Fleeing);
        }
        else if (currentState != CreatureState.Chasing && currentState != CreatureState.Attacking)
        {
            // If attacked, and not already chasing/attacking, ensure it targets attacker (player)
            if (playerController != null)
            {
                SetTarget(playerController.transform);
            }
        }
    }

    /// <summary>
    /// Handles the creature's death, playing effects and notifying relevant systems.
    /// </summary>
    public void Die()
    {
        if (isDead) return;

        isDead = true;
        ChangeState(CreatureState.Dead);
        Debug.Log($"{gameObject.name} has died.");

        navMeshAgent.isStopped = true;
        // Disable renderer and collider to signify death, or play death animation
        Collider creatureCollider = GetComponent<Collider>();
        if (creatureCollider != null) creatureCollider.enabled = false;
        Renderer creatureRenderer = GetComponentInChildren<Renderer>();
        if (creatureRenderer != null) creatureRenderer.enabled = false; // Or swap to a dead model/ragdoll

        audioManager?.PlaySFX(deathSound, transform.position);

        // Notify QuestManager if there's a quest objective linked to this creature's death
        if (!string.IsNullOrEmpty(questObjectiveOnDeathID))
        {
            questManager?.ProgressQuest(GetQuestIDFromObjectiveID(questObjectiveOnDeathID), questObjectiveOnDeathID);
        }

        // Example: Spawn a death effect (e.g., particles)
        // objectPoolManager?.SpawnObject("DeathEffectPrefab", transform.position, Quaternion.identity);

        // After a delay, return to object pool (or destroy)
        Invoke(nameof(ReturnToPool), 5f); // Disappear after 5 seconds
    }

    /// <summary>
    /// Changes the current state of the creature's AI.
    /// </summary>
    /// <param name="newState">The new state to transition to.</param>
    public void ChangeState(CreatureState newState)
    {
        if (isDead && newState != CreatureState.Dead) return; // Cannot change state if dead, unless setting to Dead

        if (currentState == newState) return; // No change needed

        // Exit current state logic (if any)
        switch (currentState)
        {
            case CreatureState.Attacking:
                // Stop attack animation if playing
                break;
            case CreatureState.Chasing:
            case CreatureState.Patrolling:
            case CreatureState.Fleeing:
                if (navMeshAgent.isOnNavMesh)
                {
                    navMeshAgent.isStopped = true; // Stop movement before changing state
                }
                break;
        }

        currentState = newState;
        Debug.Log($"{gameObject.name} changed state to: {currentState}");

        // Enter new state logic
        switch (currentState)
        {
            case CreatureState.Idle:
                navMeshAgent.isStopped = true;
                navMeshAgent.speed = patrolSpeed; // Reset speed, might be changed by chase/flee
                currentTarget = null;
                break;
            case CreatureState.Patrolling:
                navMeshAgent.isStopped = false;
                navMeshAgent.speed = patrolSpeed;
                SetNewPatrolDestination();
                break;
            case CreatureState.Chasing:
                navMeshAgent.isStopped = false;
                navMeshAgent.speed = chaseSpeed;
                break;
            case CreatureState.Attacking:
                navMeshAgent.isStopped = true;
                lastAttackTime = Time.time; // Reset attack timer for immediate attack possibility
                break;
            case CreatureState.Fleeing:
                navMeshAgent.isStopped = false;
                navMeshAgent.speed = chaseSpeed * 1.2f; // Flee faster than chasing
                FindFleeDestination();
                break;
            case CreatureState.Dead:
                // Specific death handling already in Die()
                navMeshAgent.enabled = false; // Disable NavMeshAgent
                break;
        }
    }

    // --- State Handlers ---

    private void HandleIdleState()
    {
        // In Idle state, check for player detection
        if (CanSeePlayer())
        {
            SetTarget(playerController.transform);
        }
        else
        {
            // After some time, perhaps transition to patrolling
            if (UnityEngine.Random.value < Time.deltaTime * 0.05f) // 5% chance per second
            {
                ChangeState(CreatureState.Patrolling);
            }
        }
    }

    private void HandlePatrollingState()
    {
        if (CanSeePlayer())
        {
            SetTarget(playerController.transform);
            return;
        }

        if (!navMeshAgent.pathPending && navMeshAgent.remainingDistance < NAVMESH_PATH_THRESHOLD)
        {
            SetNewPatrolDestination();
        }
    }

    private void HandleChasingState()
    {
        if (currentTarget == null || playerStats.IsDead())
        {
            ChangeState(CreatureState.Idle); // Lose target if player is dead or target is gone
            return;
        }

        if (Vector3.Distance(transform.position, currentTarget.position) <= attackRange)
        {
            ChangeState(CreatureState.Attacking);
        }
        else if (Vector3.Distance(transform.position, currentTarget.position) > detectionRange * 1.5f) // Player too far
        {
            ChangeState(CreatureState.Idle);
        }
        else
        {
            // Only update destination if agent is not already close or path pending
            if (!navMeshAgent.pathPending && navMeshAgent.remainingDistance > NAVMESH_PATH_THRESHOLD)
            {
                if (navMeshAgent.isOnNavMesh)
                {
                    navMeshAgent.SetDestination(currentTarget.position);
                }
            }
        }
    }

    private void HandleAttackingState()
    {
        if (currentTarget == null || playerStats.IsDead())
        {
            ChangeState(CreatureState.Idle);
            return;
        }

        // Keep facing the target
        Vector3 directionToTarget = (currentTarget.position - transform.position).normalized;
        Quaternion lookRotation = Quaternion.LookRotation(new Vector3(directionToTarget.x, 0, directionToTarget.z));
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f);

        if (Vector3.Distance(transform.position, currentTarget.position) > attackRange * 1.1f) // If target moved out of range
        {
            ChangeState(CreatureState.Chasing);
            return;
        }

        if (Time.time >= lastAttackTime + attackCooldown)
        {
            PerformAttack();
            lastAttackTime = Time.time;
        }
    }

    private void HandleFleeingState()
    {
        if (health > fleeHealthThreshold * 1.5f || Vector3.Distance(transform.position, currentTarget.position) > detectionRange * 2f)
        {
            // If recovered or far enough, revert to idle/patrol
            ChangeState(CreatureState.Idle);
            return;
        }

        if (!navMeshAgent.pathPending && navMeshAgent.remainingDistance < NAVMESH_PATH_THRESHOLD)
        {
            FindFleeDestination();
        }
    }

    // --- Helper Methods ---

    private void SetNewPatrolDestination()
    {
        Vector3 randomPoint = worldManager.GetRandomNavigablePoint(transform.position, patrolRadius);
        if (randomPoint != Vector3.zero)
        {
            if (navMeshAgent.isOnNavMesh)
            {
                navMeshAgent.SetDestination(randomPoint);
            }
            patrolDestination = randomPoint;
        }
        else
        {
            Debug.LogWarning($"CreatureAI: Could not find valid patrol point for {gameObject.name}. Retrying.");
            // If no point found, stay in idle for a bit or try again later
            ChangeState(CreatureState.Idle);
            Invoke(nameof(SetNewPatrolDestination), 2f); // Retry after 2 seconds
        }
    }

    private void FindFleeDestination()
    {
        if (currentTarget == null)
        {
            ChangeState(CreatureState.Idle);
            return;
        }

        Vector3 fleeDirection = (transform.position - currentTarget.position).normalized;
        Vector3 targetFleePoint = transform.position + fleeDirection * detectionRange * 2f; // Try to flee far

        // Try to find a navigable point in the flee direction
        Vector3 destination = worldManager.GetRandomNavigablePoint(targetFleePoint, patrolRadius * 2f);
        if (destination != Vector3.zero)
        {
            if (navMeshAgent.isOnNavMesh)
            {
                navMeshAgent.SetDestination(destination);
            }
        }
        else
        {
            Debug.LogWarning($"CreatureAI: Could not find valid flee point for {gameObject.name}. Trying again soon.");
            // If no flee point found, just try to move away randomly or stay put
            // This case might mean creature is cornered, could lead to different behavior
        }
    }

    private bool CanSeePlayer()
    {
        if (playerController == null || playerStats.IsDead()) return false;

        // Check distance
        float distanceToPlayer = Vector3.Distance(transform.position, playerController.transform.position);
        if (distanceToPlayer > detectionRange) return false;

        // Check line of sight (raycast)
        Vector3 directionToPlayer = (playerController.transform.position - transform.position).normalized;
        RaycastHit hit;
        if (Physics.Raycast(transform.position, directionToPlayer, out hit, detectionRange, obstacleLayer | playerLayer))
        {
            // If the raycast hits the player first, then line of sight is clear
            if (((1 << hit.collider.gameObject.layer) & playerLayer) != 0)
            {
                return true;
            }
        }
        return false;
    }

    private void PerformAttack()
    {
        if (playerStats == null || currentTarget == null) return;

        // Ensure player is still within attack range
        if (Vector3.Distance(transform.position, currentTarget.position) > attackRange * 1.1f)
        {
            ChangeState(CreatureState.Chasing);
            return;
        }

        // Apply damage to player
        playerStats.AdjustHealth(-attackDamage);
        audioManager?.PlaySFX(attackSound, transform.position);
        Debug.Log($"{gameObject.name} attacked {currentTarget.name} for {attackDamage} damage.");

        // Optional: Trigger attack animation here
    }

    private void ReturnToPool()
    {
        objectPoolManager?.ReturnObject(gameObject);
        // Reset state for next use if pooling
        health = 100f;
        isDead = false;
        Collider creatureCollider = GetComponent<Collider>();
        if (creatureCollider != null) creatureCollider.enabled = true;
        Renderer creatureRenderer = GetComponentInChildren<Renderer>();
        if (creatureRenderer != null) creatureRenderer.enabled = true;
        if (navMeshAgent != null) navMeshAgent.enabled = true;
        ChangeState(CreatureState.Idle); // Reset to idle
    }

    /// <summary>
    /// Helper to find the Quest ID given an Objective ID. This assumes objective IDs are unique across all quests.
    /// In a very large game, a more robust mapping might be needed.
    /// </summary>
    /// <param name="objectiveID">The objective ID.</param>
    /// <returns>The Quest ID string, or an empty string if not found.</returns>
    private string GetQuestIDFromObjectiveID(string objectiveID)
    {
        if (questManager == null) return string.Empty;

        // This is an inefficient lookup. In a real project, QuestManager could provide a direct mapping.
        // For now, it iterates through all quests to find the one containing the objective.
        foreach (QuestData quest in questManager.allQuests)
        {
            if (quest.Objectives.Exists(obj => obj.ObjectiveID == objectiveID))
            {
                return quest.QuestID;
            }
        }
        Debug.LogWarning($"CreatureAI: Could not find parent QuestID for objective '{objectiveID}'.");
        return string.Empty;
    }
}